/**
 * 提供一个程序的主方法入口
 *
 * @author 2020303122_LJX
 * @version 1.0.0
 */
public class App {

    public static void main(String[] args) {
        new AppFrame();
    }
}
