import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.io.InputStream;

/**
 * 程序的JFrame框架，提供主窗体和菜单以及实现菜单中的功能
 *
 * @author 2020303122_LJX
 * @version 1.0.5
 */
public class AppFrame extends JFrame {
    //窗口尺寸:1600x900(16:9)
    static final int WIDTH = 1600; //窗口宽度
    static final int HEIGHT = 900; //窗口高度
    static final String TITLE = "文字游戏"; //标题
    static final String ICON_NAME = "/res/icon.png"; //图标文件路径

    JMenuBar jMenuBar;
    JMenu option, about;
    JMenuItem back, restart, exit;
    JMenuItem tips, author;
    JFrame tipsFrame, authorFrame;
    JPanel window;

    public AppFrame() {
        //初始化窗口
        initFrame();
        //初始化菜单栏
        initBar();
        //立即显示
        this.setVisible(true);
        //显示主界面
        this.setWindow(new MainMenu(this));
    }

    /**
     * 初始化窗体框架
     */
    void initFrame() {
        try {
            //获取系统对应的LookAndFeel名
            String lookAndFeel = UIManager.getSystemLookAndFeelClassName();
            //设置为系统对应的LookAndFeel
            UIManager.setLookAndFeel(lookAndFeel);
            //立即应用
            SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception e) {
            LoggerUtil.getLogger().log(LoggerUtil.INFO, "切换 look-and-feel 失败");
        }

        //设置标题
        this.setTitle(TITLE);
        //设置窗口大小
        this.setSize(WIDTH, HEIGHT);
        //禁止用户改变窗口大小
        this.setResizable(false);
        //关闭窗口即结束程序
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //在屏幕中间显示
        this.setLocationRelativeTo(null);
        //设置图标
        try {
            InputStream icon = this.getClass().getResourceAsStream(ICON_NAME);
            if (icon != null) {
                Image img = ImageIO.read(icon);
                this.setIconImage(img);
            } else {
                LoggerUtil.getLogger().log(LoggerUtil.INFO, "读取图标文件失败");
            }
        } catch (IOException ioe) {
            LoggerUtil.getLogger().log(LoggerUtil.INFO, "找不到图标文件");
        }
        //JFrame设为边界布局
        this.setLayout(new BorderLayout());
        //以一个JPanel作为主窗体
        window = new JPanel();
        //背景色为黑
        window.setBackground(Color.BLACK);
        //添加至JFrame中央
        this.getContentPane().add("Center", window);
        //使窗口可见
        this.setVisible(true);
    }


    /**
     * 初始化菜单栏
     */
    void initBar() {
        jMenuBar = new JMenuBar();

        option = new JMenu(" 游戏选项 ");
        back = new JMenuItem("回主界面");
        restart = new JMenuItem("时间回溯");
        exit = new JMenuItem("退出游戏");
        option.add(back);
        option.add(restart);
        option.add(exit);

        about = new JMenu(" 关 于 ");
        tips = new JMenuItem("操作说明");
        author = new JMenuItem("制作人员");
        about.add(tips);
        about.add(author);

        jMenuBar.add(option);
        jMenuBar.add(about);

        //添加监听器
        BarListener barListener = new BarListener(this);
        back.addActionListener(barListener);
        restart.addActionListener(barListener);
        exit.addActionListener(barListener);
        tips.addActionListener(barListener);
        author.addActionListener(barListener);
        //设置菜单栏
        this.setJMenuBar(jMenuBar);
    }

    /**
     * 移除Frame上的所有监听器
     */
    void removeListeners() {
        for (KeyListener k : this.getKeyListeners()) {
            this.removeKeyListener(k);
        }
        for (MouseListener m : this.getMouseListeners()) {
            this.removeMouseListener(m);
        }
    }

    /**
     * 改变当前窗体显示内容
     *
     * @param newWindowPanel 新的窗体内容
     */
    void setWindow(JPanel newWindowPanel) {
        this.remove(window);
        window = newWindowPanel;
        this.getContentPane().add("Center", window);
        this.setVisible(true);
    }

    /**
     * 菜单监听器类
     */
    private class BarListener implements ActionListener {
        AppFrame appFrame;

        public BarListener(AppFrame frame) {
            this.appFrame = frame;
        }

        /**
         * 实现菜单监听器的方法
         *
         * @param e ActionEvent 活动事件
         */
        public void actionPerformed(ActionEvent e) {
            //返回菜单
            if (e.getSource() == back) {
                appFrame.removeListeners();
                appFrame.setWindow(new MainMenu(appFrame));
            }
            //重试本关
            if (e.getSource() == restart) {
                if (appFrame.window instanceof Level) {
                    ((Level) appFrame.window).reset();
                } else if (appFrame.window instanceof MainMenu) {
                    ((MainMenu) window).reset();
                }
            }
            //退出
            if (e.getSource() == exit) {
                appFrame.dispose();
                System.exit(0);
            }
            //操作说明
            if (e.getSource() == tips) {
                if (tipsFrame != null) {
                    //仅允许存在一个窗口
                    tipsFrame.dispose();
                }
                initTipsFrame();
            }
            //制作人员
            if (e.getSource() == author) {
                if (authorFrame != null) {
                    //仅允许存在一个窗口
                    authorFrame.dispose();
                }
                initAuthorFrame();
            }
        }

        /**
         * 初始化操作说明的窗体并显示
         */
        void initTipsFrame() {
            tipsFrame = new JFrame("操作说明");
            tipsFrame.setLayout(new BorderLayout());
            tipsFrame.setSize(1024, 576);
            //设置图标
            try {
                InputStream icon = this.getClass().getResourceAsStream(ICON_NAME);
                if (icon != null) {
                    Image img = ImageIO.read(icon);
                    tipsFrame.setIconImage(img);
                } else {
                    LoggerUtil.getLogger().log(LoggerUtil.INFO, "读取图标文件失败");
                }
            } catch (IOException ioe) {
                LoggerUtil.getLogger().log(LoggerUtil.INFO, "找不到图标文件");
            }
            tipsFrame.setLocationRelativeTo(null);
            tipsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JPanel tipsWindow = new JPanel();
            tipsWindow.setBackground(Color.WHITE);
            tipsWindow.setLayout(new GridLayout());
            tipsFrame.getContentPane().add("Center", tipsWindow);
            JTextArea textArea = new JTextArea();
            textArea.setFont(new Font("宋体", Font.PLAIN, 24));
            textArea.setBackground(Color.WHITE);
            textArea.setForeground(Color.BLACK);
            String tipsMessage = "\n操作说明:\n\n" +
                    "按WASD或方向键进行移动\n\n" +
                    "按下空格键与特定物品/文字进行交互\n\n" +
                    "在取得神器后，一些特定的文字可以进行特殊操作:\n" +
                    "  ·贝克思贝斯之剑:\n" +
                    "     删除(按下K键进行删除)\n" +
                    "  ·杜尔手套:\n" +
                    "     推(移动时可直接推动)\n" +
                    "     拉(按下L键与物品连接，即可拉动)\n\n" +
                    "通过交互、删除和推拉破解谜题吧!";
            textArea.setText(tipsMessage);
            tipsWindow.add(textArea);
            tipsFrame.setVisible(true);
        }

        /**
         * 初始化作者信息的窗体并显示
         */
        void initAuthorFrame() {
            authorFrame = new JFrame("制作人员");
            authorFrame.setLayout(new BorderLayout());
            authorFrame.setSize(1024, 576);
            //设置图标
            try {
                InputStream icon = this.getClass().getResourceAsStream(ICON_NAME);
                if (icon != null) {
                    Image img = ImageIO.read(icon);
                    authorFrame.setIconImage(img);
                } else {
                    LoggerUtil.getLogger().log(LoggerUtil.INFO, "读取图标文件失败");
                }
            } catch (IOException ioe) {
                LoggerUtil.getLogger().log(LoggerUtil.INFO, "找不到图标文件");
            }
            authorFrame.setLocationRelativeTo(null);
            authorFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JPanel authorWindow = new JPanel();
            authorWindow.setBackground(Color.WHITE);
            authorWindow.setLayout(new GridLayout());
            authorFrame.getContentPane().add("Center", authorWindow);
            JTextArea textArea = new JTextArea();
            textArea.setFont(new Font("宋体", Font.BOLD, 30));
            textArea.setBackground(Color.WHITE);
            textArea.setForeground(Color.BLUE);
            String authorMessage = "制作人员:\n" +
                    "2020303118 - 蔡柳扬\n" +
                    "2020303120 - 童嘉文\n" +
                    "2020303122 - 李佳鑫\n" +
                    "2020303138 - 李骏逸\n" +
                    "2020303140 - 秦  臻";
            textArea.setText(authorMessage);
            authorWindow.add(textArea);
            authorFrame.setVisible(true);
        }
    }
}
