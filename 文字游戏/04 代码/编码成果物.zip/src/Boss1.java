import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * @author 2020303120_Allen
 * @version 1.0.3
 */
public class Boss1 extends Level {

    // 拓展的交互类型
    static final int TIP = 1;
    static final int CUT = 2;
    static final int WALL = 3;
    static final int BOX = 4;
    static final int DRAGON = 6;
    static final int DELETE = 7;
    static final int FIRE = 8;
    static final int EYE = 9;
    static final int TOOTH = 10;
    static final int HEAD = 11;
    static final int LEAVE = 12;

    int[] moveFlags = {EYE, TOOTH, HEAD, LEAVE};

    int another = 0;
    int scence = 0;

    public Boss1(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        clearLabels();
        initMe(2, 8, Color.BLUE);
        setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 0, MAX_COLUMN, WALL);
        setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 15, MAX_COLUMN, WALL);
        setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 1, 1, WALL);
        setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 30, 1, 1, WALL);
        setLabelsText("龍", 24, 7, 2, DRAGON, Color.GREEN);
        setLabelsText("眼", 23, 8, 1, DRAGON, Color.RED);
        setLabelsText("龍龍龍", 24, 8, 3, DRAGON, Color.GREEN);
        if (scence == 0) {
            setLabelsText("【龙堡里黑漆漆的，还好带了灯进来】勇者暗自庆幸到▼   ", 2, 2, 30, TIP, Color.white);
        } else if (scence == 1) {
            setLabelsText("恶龙吼叫着，  在说着什么▼                ", 2, 2, 28, TIP, Color.white);
            setLabelsText("似乎", 8, 2, 31, CUT, Color.LIGHT_GRAY);
        } else if (scence == 2) {
            setLabelsText("要怎样才可以战胜恶龙▼                  ", 2, 2, 28, TIP, Color.white);
        } else if (scence == 3) {
            setLabelsText("恶龙口中吐出龙炎，龙堡顿时化为火海                  ", 2, 2, 28, TIP, Color.white);
            setLabelsText("炎炎炎", 13, 4, 1, FIRE, Color.RED);
            setLabelsText("炎", 12, 5, 1, FIRE, Color.RED);
            setLabelsText("火", 14, 5, 1, FIRE, Color.YELLOW);
            setLabelsText("炎炎炎", 13, 9, 1, FIRE, Color.RED);
            setLabelsText("炎", 12, 10, 1, FIRE, Color.RED);
            setLabelsText("火", 14, 10, 1, FIRE, Color.YELLOW);
            setLabelsText("挥舞着贝克思贝斯之剑， 龙焰毫无办法", 3, 8, 19, TIP, Color.white);
            setLabelsText("对", 14, 8, 1, DELETE, Color.white);
        } else if (scence == 4) {
            setLabelsText("挥舞着贝克思贝斯之剑，龙焰毫无办法  ", 3, 8, 19, TIP, Color.white);
            setLabelsText("   ", 13, 4, 1, TIP);
            setLabelsText(" ", 12, 5, 1, TIP);
            setLabelsText(" ", 12, 5, 1, TIP);
            setLabelsText("   ", 13, 9, 1, FIRE, Color.RED);
            setLabelsText(" ", 12, 10, 1, FIRE, Color.RED);
            setLabelsText(" ", 14, 10, 1, FIRE, Color.YELLOW);
            setLabelsText("恶龙过于强大， 有一个办法将其斩杀                   ", 2, 2, 28, TIP, Color.white);
            setLabelsText("没", 9, 2, 28, DELETE, Color.white);
        } else if (scence == 5) {
            setLabelsText("恶龙过于强大，有一个办法将其斩杀                    ", 2, 2, 28, TIP, Color.white);
            setLabelsText("将独眼暴君之 ，幽冥影豹之                  ", 2, 3, 28, TIP, Color.white);
            setLabelsText("美杜莎之 ，荆棘魔花之 ", 2, 6, 28, TIP, Color.white);
            setLabelsText("按照其获得方位放于法阵上", 2, 9, 28, TIP, Color.white);

            setLabelsText("眼", 8, 3, 1, EYE, Color.BLUE);
            setLabelsText("牙", 15, 3, 1, TOOTH, Color.GRAY);
            setLabelsText("首", 6, 6, 1, HEAD, Color.ORANGE);
            setLabelsText("叶", 13, 6, 1, LEAVE, Color.GREEN);
            setLabelsText("█", 20, 9, 1, BOX, Color.WHITE);
            setLabelsText("█", 24, 5, 1, BOX, Color.WHITE);
            setLabelsText("█", 29, 9, 1, BOX, Color.WHITE);
            setLabelsText("█", 24, 12, 1, BOX, Color.WHITE);
        }
    }

    /**
     * 重置本关（时间回溯） 必要时进行覆写
     */
    @Override
    public void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        this.scence = 0;
        this.another = 0;
        initMap();
        this.setVisible(true);
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {

        Boss1 boss1;

        public MoveListener(Boss1 boss1) {
            this.boss1 = boss1;
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {
            if (another != 2) {
                if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                    moveMe(DOWN, moveFlags);
                } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                    moveMe(UP, moveFlags);
                } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                    moveMe(LEFT, moveFlags);
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                    moveMe(RIGHT, moveFlags);
                }
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    if (scence <= 2) {
                        scence += 1;
                        initMap();
                    }
                    int flag = getFlag();
                    if (flag == WALL) {
                        setLabelsText("一面平平无奇的墙，摸起来质地粗糙。", 3, 3, TEXT);
                    }
                } else if (e.getKeyCode() == KeyEvent.VK_L) {
                    linkedFlag = !linkedFlag;
                } else if (e.getKeyCode() == KeyEvent.VK_K) {
                    int flag = getFlag();
                    if (flag == CUT) {
                        deleteFront();
                        another += 1;
                    } else if (flag == DELETE) {
                        deleteFront();
                        scence++;
                        initMap();
                    }
                }
                if (boss1.flags[4][24] == EYE && boss1.flags[11][24] == TOOTH && boss1.flags[8][20] == HEAD
                        && boss1.flags[8][29] == LEAVE) {
                    scence = 6;
                    if (e.getKeyCode() == KeyEvent.VK_K) {
                        int flag = getFlag();
                        if (flag == DRAGON) {
                            setLabelsText("恶龙发出了一声哀鸣，被勇者斩下了头颅▼", 2, 2, TEXT);
                            setLabelsText("                      ", 2, 3, 28, TIP, Color.white);
                            setLabelsText("                      ", 2, 6, 28, TIP, Color.white);
                            setLabelsText("获得诅咒【   】         ", 2, 9, 31, TEXT);
                            setLabelsText("屠龙者", 7, 9, 31, TEXT, Color.RED);

                        }
                    }

                }
                if (boss1.me_column >= 11 && boss1.me_column <= 14 && boss1.me_row >= 4 && boss1.me_row <= 6) {
                    if (scence == 3) {
                        another = 0;
                        scence = 0;
                        boss1.appFrame.removeListeners();
                        boss1.appFrame.setWindow(new DeadEnding(this.boss1.appFrame));
                    }
                }
            } else if (another == 2) {
                setLabelsText("获得能力【   】", 2, 9, 31, TEXT);
                setLabelsText("龙语者", 7, 9, 31, TEXT, Color.YELLOW);
                if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                    moveMe(DOWN, moveFlags);
                } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                    moveMe(UP, moveFlags);
                } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                    moveMe(LEFT, moveFlags);
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                    moveMe(RIGHT, moveFlags);
                } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    int flag = getFlag();
                    if (flag == DRAGON) {
                        scence += 1;
                        if (scence == 3) {
                            setLabelsText("【         】魔龙说到", 2, 2, 28, TEXT);
                            setLabelsText("为何要打扰我的长眠", 3, 2, 28, TEXT, Color.RED);
                        } else if (scence == 4) {
                            setLabelsText("【      】我回答到", 2, 4, 28, TEXT);
                            setLabelsText("因为我是勇者", 3, 4, 28, TEXT, Color.BLUE);
                        } else if (scence == 5) {
                            setLabelsText("【               】魔龙说到", 2, 2, 28, TEXT);
                            setLabelsText("勇者就一定要屠龙，什么SB剧情", 3, 2, 28, TEXT, Color.RED);
                        } else if (scence == 6) {
                            setLabelsText("【                   】我回答到", 2, 4, 28, TEXT);
                            setLabelsText("勇者的使命一直都是，巫师就是这么说的", 3, 4, 28, TEXT, Color.BLUE);
                        } else if (scence == 7) {
                            setLabelsText("【              】魔龙戏谑道", 2, 2, 28, TEXT);
                            setLabelsText("所以你是巫师的傀儡，还是勇者", 3, 2, 28, TEXT, Color.RED);
                        } else if (scence == 8) {
                            setLabelsText("【      】我沉默了               ", 2, 4, 28, TEXT);
                            setLabelsText("......", 3, 4, 28, TEXT, Color.BLUE);
                        } else if (scence == 9) {
                            setLabelsText("【            】我如是说到          ", 2, 2, 28, TEXT);
                            setLabelsText("或许我应该拥有自己的目标", 3, 2, 28, TEXT, Color.BLUE);
                        } else if (scence == 10) {
                            setLabelsText("【                  】魔龙不再犯困", 2, 4, 28, TEXT);
                            setLabelsText("你是一个有趣的勇者，比之前的有趣多了", 3, 4, 28, TEXT, Color.RED);
                        } else if (scence == 11) {
                            boss1.appFrame.removeListeners();
                            boss1.appFrame.setWindow(new GoodEnding(this.boss1.appFrame));
                        }
                    }

                }
            }
            if (boss1.me_column >= 23 && boss1.me_column <= 26 && boss1.me_row >= 7 && boss1.me_row <= 9
                    || (boss1.me_column == 22 && boss1.me_row == 8) || (boss1.me_column == 27 && boss1.me_row == 8)) {
                if (another == 0 && scence != 6) {
                    another = 0;
                    scence = 0;
                    boss1.appFrame.removeListeners();
                    boss1.appFrame.setWindow(new DeadEnding(this.boss1.appFrame));
                }
                if (scence == 6 && (e.getKeyCode() == KeyEvent.VK_SPACE) && another == 0) {
                    another = 0;
                    scence = 0;
                    boss1.appFrame.removeListeners();
                    boss1.appFrame.setWindow(new End(this.boss1.appFrame));
                }
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}