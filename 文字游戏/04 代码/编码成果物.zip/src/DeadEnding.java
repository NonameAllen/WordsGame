import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 过于靠近龙而死亡结局
 *
 * @author 2020303120_Allen
 * @version 1.0.3
 */
public class DeadEnding extends Level {

    // 拓展的交互类型
    static final int WALL = 3;

    int scene = 0;

    public DeadEnding(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (scene == 0) {
            setLabelsText("我", 3, 1, 1, WALL, Color.lightGray);
            setLabelsText("死", 3, 2, 1, WALL, Color.RED);
            setLabelsText("了", 3, 3, 1, WALL);
            setLabelsText("▼", 3, 4, 1, WALL);
        } else if (scene == 1) {
            setLabelsText("勇者最终还是死在了  的爪下", 8, 1, 1, WALL);
            setLabelsText("恶龙", 8, 10, 1, WALL, Color.GREEN);
            setLabelsText("▼", 8, 14, 1, WALL);
        } else if (scene == 2) {
            setLabelsText("也许", 13, 1, 1, WALL, Color.GREEN);
            setLabelsText(" 我不应该  靠近  ", 13, 3, 1, WALL);
            setLabelsText("恶龙", 13, 11, 1, WALL, Color.GREEN);
            setLabelsText("和他的", 14, 1, 1, WALL);
            setLabelsText("龙炎", 14, 4, 1, WALL, Color.YELLOW);
            setLabelsText("过", 13, 7, 1, WALL, Color.RED);
            setLabelsText("于", 13, 8, 1, WALL, Color.RED);
            setLabelsText("▼", 14, 6, 1, WALL);
        } else if (scene == 3) {
            setLabelsText("只可惜没有  ······", 18, 1, 1, WALL);
            setLabelsText("也许", 18, 6, 1, WALL, Color.GREEN);
        } else if (scene == 4) {
            setLabelsText("||达成结局", 23, 4, 1, WALL, Color.RED);
            setLabelsText(" 没有也许", 23, 10, 1, WALL, Color.GREEN, new Font("华文新魏", Font.BOLD, 47));
        }
    }

    @Override
    public void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        this.scene = 0;
        initMap();
        this.setVisible(true);
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {

        DeadEnding deadending;

        public MoveListener(DeadEnding deadEnding) {
            this.deadending = deadEnding;
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (deadending.scene <= 4) {
                    initMap();
                    deadending.scene += 1;
                } else {
                    deadending.appFrame.removeListeners();
                    deadending.appFrame.setWindow(new MainMenu(this.deadending.appFrame));
                }
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
