import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 最终关卡遇见恶龙没有带灯而死亡结局
 *
 * @author 2020303120_Allen
 * @version 1.0.3
 */
public class DeadEnding1 extends Level {

    // 拓展的交互类型
    static final int WALL = 3;

    int scene;

    public DeadEnding1(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (scene == 0) {
            setLabelsText("我", 4, 1, 1, WALL, Color.lightGray);
            setLabelsText("死", 4, 2, 1, WALL, Color.RED);
            setLabelsText("了", 4, 3, 1, WALL);
            setLabelsText("▼", 4, 4, 1, WALL);
        } else if (scene == 1) {
            setLabelsText("勇者只在黑暗中看见了恶龙那  ", 8, 1, 1, WALL);
            setLabelsText("血红", 8, 14, 1, WALL, Color.RED);
            setLabelsText("的", 9, 1, 1, WALL);
            setLabelsText("眼睛", 9, 2, 1, WALL, Color.RED);
            setLabelsText("▼", 9, 4, 1, WALL);
        } else if (scene == 2) {
            setLabelsText("如果", 13, 1, 1, WALL, Color.BLUE);
            setLabelsText("带了 的话就可以与恶龙搏斗", 13, 3, 1, WALL);
            setLabelsText("灯", 13, 5, 1, WALL, Color.YELLOW);
            setLabelsText("了吧▼", 14, 1, 1, WALL);
        } else if (scene == 3) {
            setLabelsText("只可惜没有  ······", 18, 1, 1, WALL);
            setLabelsText("如果", 18, 6, 1, WALL, Color.BLUE);
        } else if (scene == 4) {
            setLabelsText("||达成结局", 23, 4, 1, WALL, Color.RED);
            setLabelsText(" 没有如果", 23, 10, 1, WALL, Color.BLUE, new Font("华文新魏", Font.BOLD, 47));
        }
    }

    @Override
    public void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        this.scene = 0;
        initMap();
        this.setVisible(true);
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {

        DeadEnding1 deadending1;

        public MoveListener(DeadEnding1 deadEnding1) {
            this.deadending1 = deadEnding1;
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (deadending1.scene <= 4) {
                    initMap();
                    deadending1.scene += 1;
                } else {
                    deadending1.appFrame.removeListeners();
                    deadending1.appFrame.setWindow(new MainMenu(this.deadending1.appFrame));
                }
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
