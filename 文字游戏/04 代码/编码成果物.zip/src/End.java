import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 龙语者结局
 *
 * @author 2020303120_Allen
 * @version 1.0.3
 */
public class End extends Level {

    // 拓展的交互类型
    static final int WALL = 3;

    int scene = 0;

    public End(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (scene == 0) {
            setLabelsText("我", 3, 1, 1, WALL, Color.RED);
            setLabelsText("离开了龙堡", 3, 2, 1, WALL);
            setLabelsText("▼", 3, 7, 1, WALL);
        } else if (scene == 1) {
            setLabelsText("恶龙", 6, 1, 1, WALL, Color.GREEN);
            setLabelsText("被 杀死了", 6, 3, 1, WALL);
            setLabelsText("我", 6, 4, 1, WALL, Color.RED);
            setLabelsText("▼", 6, 7, 1, WALL);
        } else if (scene == 2) {
            setLabelsText("我", 9, 1, 1, WALL, Color.RED);
            setLabelsText("的身体也被  的  给染红", 9, 2, 1, WALL);
            setLabelsText("恶龙", 9, 7, 1, WALL, Color.GREEN);
            setLabelsText("鲜血", 9, 10, 1, WALL, Color.RED);
            setLabelsText("▼", 9, 15, 1, WALL);
        } else if (scene == 3) {
            setLabelsText("但  再也没把我当成拯救人类的", 12, 1, 1, WALL);
            setLabelsText("大家", 12, 2, 1, WALL, Color.BLUE);
            setLabelsText("勇者", 13, 1, 1, WALL, Color.YELLOW);
            setLabelsText("来尊敬▼", 13, 3, 1, WALL);
        } else if (scene == 4) {
            setLabelsText("我是  ，同时也是", 16, 1, 1, WALL);
            setLabelsText("勇者", 16, 3, 1, WALL, Color.YELLOW);
            setLabelsText("屠龙者", 16, 10, 1, WALL, Color.RED);
            setLabelsText("▼", 16, 13, 1, WALL);
        } else if (scene == 5) {
            setLabelsText("人们看我的  ，我见过▼ ", 19, 1, 1, WALL);
            setLabelsText("眼神", 19, 6, 1, WALL, Color.RED);
        } else if (scene == 6) {
            setLabelsText("那是人们看  的", 22, 1, 1, WALL);
            setLabelsText("恶龙", 22, 6, 1, WALL, Color.RED);
            setLabelsText("眼神", 22, 9, 1, WALL, Color.RED);
            setLabelsText("▼", 22, 11, 1, WALL);
        } else if (scene == 7) {
            setLabelsText("或许 就是      。", 25, 1, 1, WALL);
            setLabelsText("这", 25, 3, 1, WALL, Color.RED);
            setLabelsText("屠龙者的诅咒", 25, 7, 1, WALL, Color.RED);
        } else if (scene == 8) {
            setLabelsText("||达成结局", 28, 5, 1, WALL, Color.RED);
            setLabelsText(" 屠龙者", 28, 11, 1, WALL, Color.RED, new Font("华文新魏", Font.BOLD, 47));
        }
    }

    @Override
    public void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        this.scene = 0;
        initMap();
        this.setVisible(true);
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {

        End ending;

        public MoveListener(End Ending) {
            this.ending = Ending;
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (ending.scene <= 8) {
                    initMap();
                    ending.scene += 1;
                } else {
                    ending.appFrame.removeListeners();
                    ending.appFrame.setWindow(new MainMenu(this.ending.appFrame));
                }
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}