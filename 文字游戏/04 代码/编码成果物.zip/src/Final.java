import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 最终关卡，城堡长廊
 *
 * @author 2020303120_Allen
 * @author (fixed by 2020303122_LJX)
 * @version 1.1.0
 */
public class Final extends Level {

    //拓展的交互类型
    static final int TIP = 4;
    static final int CUT = 5;
    static final int WALL = 6;
    static final int BOX = 7;
    static final int LIGHT = 8;

    boolean cutTextFlag;
    boolean cutFlag;
    int scene;
    int pick;

    int[] moveFlags = {BOX};

    public Final(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
        cutTextFlag = false;
        cutFlag = false;
        scene = 0;
        pick = 0;
    }

    /**
     * 初始化地图
     */
    void initMap() {
        initMe(0, 7, Color.LIGHT_GRAY);
        setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 1, MAX_COLUMN, WALL);
        setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 14, MAX_COLUMN, WALL);
        setLabelsText("城堡里黑漆漆的，只有几盏灯在发着暗淡的光▼", 3, 4, MAX_COLUMN, TEXT);
        setLabelsText("灯     灯           灯     灯", 2, 2, MAX_COLUMN, LIGHT, Color.YELLOW);
        setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
        setLabelsText("灯     灯     灯     灯     灯", 2, 13, MAX_COLUMN, LIGHT, Color.YELLOW);
    }

    @Override
    public void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        cutTextFlag = false;
        cutFlag = false;
        scene = 0;
        pick = 0;
        initMap();
        this.setVisible(true);
    }

    private boolean boxNotInstance() {
        for (int r = 0; r < MAX_ROW; r++) {
            for (int c = 0; c < MAX_COLUMN; c++) {
                if (flags[r][c] == BOX) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {

        Final final1;

        public MoveListener(Final final1) {
            this.final1 = final1;
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {
            if (final1.me_column == 28 && !cutTextFlag) {
                setLabelsText("只有斩断恐惧者才能通过此", 29, 2, 1, TIP);
                if (boxNotInstance()) {
                    setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
                }
                cutTextFlag = true;
            }
            if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                moveMe(DOWN, moveFlags);
            } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                moveMe(UP, moveFlags);
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                moveMe(LEFT, moveFlags);
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                moveMe(RIGHT, moveFlags);
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (!cutTextFlag) {
                    int c = me_column;
                    int r = me_row;
                    setLabelsText("先去前面去看看吧             ", 3, 4, MAX_COLUMN, TEXT);
                    if (r == 4 && c >= 11) {
                        initMe(c, r, Color.LIGHT_GRAY);
                    }
                    if (boxNotInstance()) {
                        setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
                    }
                }
                int flag = getFlag();
                if (flag == WALL) {
                    setLabelsText("不能再犹豫了，继续前行吧。    ", 3, 4, TEXT);
                    if (boxNotInstance()) {
                        setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
                    }
                } else if (flag == TIP) {
                    if (cutFlag) {
                        setLabelsText("既已斩断恐惧，那就继续前行    ", 3, 4, 31, TEXT);
                    } else {
                        setLabelsText("还 斩断自己的恐惧        ", 3, 4, 31, TEXT);
                        setLabelsText("没", 4, 4, CUT);
                    }
                    if (boxNotInstance()) {
                        setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
                    }
                } else if (flag == LIGHT) {
                    setLabelsText("灯死死的钉在墙上，", 3, 4, 31, TEXT, Color.WHITE);
                    setLabelsText("发出着微弱的黄光", 12, 4, 31, TEXT, Color.YELLOW);
                    if (boxNotInstance()) {
                        setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
                    }
                } else if (flag == BOX) {
                    setLabelsText("灯发出着微弱的黄光        ", 3, 4, 31, TEXT, Color.YELLOW);
                    if (boxNotInstance()) {
                        setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
                    }
                }
            } else if (e.getKeyCode() == KeyEvent.VK_L) {
                linkedFlag = !linkedFlag;
            } else if (e.getKeyCode() == KeyEvent.VK_K) {
                int flag = getFlag();
                if (flag == CUT) {
                    deleteFront();
                    initMe(3, 4, Color.LIGHT_GRAY);
                    setLabelsText("斩断了自己的恐惧", 4, 4, 31, TEXT);
                    setLabelsText("只有斩断  者才能通过此", 29, 2, 1, TIP);
                    if (boxNotInstance()) {
                        setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
                    }
                    cutFlag = true;
                } else if (flag != 0) {
                    setLabelsText("宝剑或许不应该用于斩断无聊的东西", 3, 4, 31, TEXT);
                    if (boxNotInstance()) {
                        setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
                    }
                }
            }
            if (final1.me_column == 29 && pick == 0) {
                setLabelsText("前方黑漆漆的，直接进入恐怕有危险", 3, 4, 31, TEXT);
                if (boxNotInstance()) {
                    setLabelsText("灯", 14, 2, 1, BOX, Color.YELLOW);
                }
                pick = 1;
            } else if (final1.me_column == 30) {
                cutTextFlag = false;
                scene = 0;
                pick = 0;
                final1.appFrame.removeListeners();
                final1.appFrame.setWindow(new DeadEnding1(this.final1.appFrame));
            }
            if (final1.flags[6][28] == BOX || final1.flags[7][28] == BOX || final1.flags[6][30] == BOX || final1.flags[7][30] == BOX) {
                final1.appFrame.removeListeners();
                final1.appFrame.setWindow(new Boss1(this.final1.appFrame));
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
