import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 龙语者结局
 *
 * @author 2020303120_Allen
 * @version 1.0.3
 */
public class GoodEnding extends Level {

    // 拓展的交互类型
    static final int WALL = 3;

    int scene = 0;

    public GoodEnding(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (scene == 0) {
            setLabelsText("我", 3, 1, 1, WALL, Color.YELLOW);
            setLabelsText("离开了龙堡", 3, 2, 1, WALL);
            setLabelsText("▼", 3, 7, 1, WALL);
        } else if (scene == 1) {
            setLabelsText("魔龙", 6, 1, 1, WALL, Color.GREEN);
            setLabelsText("陪着我一起离开了", 6, 3, 1, WALL);
            setLabelsText("▼", 6, 11, 1, WALL);
        } else if (scene == 2) {
            setLabelsText("也许我不应该对巫师和勇者的傳統", 9, 1, 1, WALL);
            setLabelsText("言听计从", 10, 1, 1, WALL, Color.RED);
            setLabelsText("▼", 10, 5, 1, WALL);
        } else if (scene == 3) {
            setLabelsText("魔龙", 13, 1, 1, WALL, Color.GREEN);
            setLabelsText("并不都是  的", 13, 3, 1, WALL);
            setLabelsText("邪恶", 13, 7, 1, WALL, Color.RED);
            setLabelsText("▼", 13, 10, 1, WALL);
        } else if (scene == 4) {
            setLabelsText("我是  ，同时也是", 16, 1, 1, WALL);
            setLabelsText("勇者", 16, 3, 1, WALL, Color.BLUE);
            setLabelsText("龙语者", 16, 10, 1, WALL, Color.YELLOW);
            setLabelsText("▼", 16, 13, 1, WALL);
        } else if (scene == 5) {
            setLabelsText("如果  的身份可以帮助人们", 19, 1, 1, WALL);
            setLabelsText("消除对 的偏见", 20, 1, 1, WALL);
            setLabelsText("勇者", 19, 3, 1, WALL, Color.YELLOW);
            setLabelsText("龙", 20, 4, 1, WALL, Color.RED);
            setLabelsText("▼", 20, 8, 1, WALL);
        } else if (scene == 6) {
            setLabelsText("或许这才是 的使命。", 23, 1, 1, WALL);
            setLabelsText("我", 23, 6, 1, WALL, Color.YELLOW);
        } else if (scene == 7) {
            setLabelsText("||达成结局", 26, 5, 1, WALL, Color.RED);
            setLabelsText(" 龙语者", 26, 11, 1, WALL, Color.YELLOW, new Font("华文新魏", Font.BOLD, 47));
        }
    }

    @Override
    public void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        this.scene = 0;
        initMap();
        this.setVisible(true);
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {

        GoodEnding goodending;

        public MoveListener(GoodEnding goodEnding) {
            this.goodending = goodEnding;
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (goodending.scene <= 7) {
                    initMap();
                    goodending.scene += 1;
                } else {
                    goodending.appFrame.removeListeners();
                    goodending.appFrame.setWindow(new MainMenu(this.goodending.appFrame));
                }
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
