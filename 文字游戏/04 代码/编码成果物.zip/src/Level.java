import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.Iterator;

/**
 * 关卡类（抽象）,提供建立关卡界面的模板和一些可以复用的方法
 *
 * @author 2020303122_LJX
 * @version 1.0.5
 */
public abstract class Level extends JPanel {
    //JLabel的最大行列数
    static final int MAX_ROW = 16;
    static final int MAX_COLUMN = 31;
    //每个JLabel的大小（正方形）
    static final int SIZE_OF_EACH_LABEL = 50;
    //由于label与窗口边界还有一些空隙,添加一些偏移使其居中显示
    static final int LABELS_OFFSET_X = 24;
    static final int LABELS_OFFSET_Y = 15;
    //用于表示“我”的移动方向
    static final int UP = 1;
    static final int DOWN = 2;
    static final int LEFT = 3;
    static final int RIGHT = 4;
    //基础的三种交互类型
    static final int BLANK = 0;  //空白
    static final int TEXT = 1;  //普通文字(会发生阻挡)
    static final int MOVE_TEXT = 2;  //可推拉文字(可以进行推拉)

    AppFrame appFrame;

    //由多个label来实现一格一格的划分
    JLabel[][] labels;
    //由一个int数组存放对应位置元素可交互类型
    int[][] flags;
    //默认的字体
    Font defaultFont = new Font("宋体", Font.PLAIN, SIZE_OF_EACH_LABEL);
    //当前“我”所在的行、列
    int me_row, me_column;
    //当前“我”的朝向
    int current_direction;
    //标明屏幕上是否有"我”存在
    boolean meFLag;
    //拉动操作时判断是否处于连接状态的标志
    boolean linkedFlag;

    /**
     * 构造方法
     *
     * @param frame 此panel所处的AppFrame
     */
    public Level(AppFrame frame) {
        this.appFrame = frame;
        //初始化标签属性
        initLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        //加载地图
        initMap();
        this.setVisible(true);
    }

    /**
     * 初始化界面上的JLabel,同时初始化标志数组flags为BLANK
     */
    private void initLabels() {
        //黑色背景
        this.setBackground(Color.BLACK);
        //手工布局
        this.setLayout(null);

        //初始化label和flag
        //label内容为" ",颜色为白,flag为BLANK
        this.labels = new JLabel[MAX_ROW][MAX_COLUMN];
        this.flags = new int[MAX_ROW][MAX_COLUMN];

        for (int row = 0; row < MAX_ROW; row++) {
            for (int column = 0; column < MAX_COLUMN; column++) {
                JLabel tempLabel = new JLabel(" ");
                labels[row][column] = tempLabel;
                flags[row][column] = BLANK;
                tempLabel.setForeground(Color.WHITE);
                tempLabel.setFont(defaultFont);
                tempLabel.setBounds(LABELS_OFFSET_X + column * SIZE_OF_EACH_LABEL, LABELS_OFFSET_Y + row * SIZE_OF_EACH_LABEL,
                        SIZE_OF_EACH_LABEL, SIZE_OF_EACH_LABEL);
                this.add(tempLabel);
            }
        }
    }

    /**
     * 清空屏幕上的所有内容(包括我),标志全部置为BLANK
     */
    void clearLabels() {
        if (labels != null && flags != null) {
            for (int row = 0; row < MAX_ROW; row++) {
                for (int column = 0; column < MAX_COLUMN; column++) {
                    labels[row][column].setForeground(Color.WHITE);
                    labels[row][column].setFont(defaultFont);
                    labels[row][column].setText(" ");
                    flags[row][column] = BLANK;
                }
            }
        }
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
    }

    /**
     * 在指定区域的标签里设置文字(会覆盖原有文字)
     * 如果含有" ",默认其交互类型为 BLANK, 文字颜色默认为白色
     *
     * @param str         文字内容
     * @param columnIndex 列的下标
     * @param rowIndex    行的下标
     * @param flagType    文字的交互类型
     */
    void setLabelsText(String str, int columnIndex, int rowIndex, int flagType) {
        setLabelsText(str, columnIndex, rowIndex, MAX_COLUMN - columnIndex, flagType);
    }

    /**
     * 在指定区域的标签里设置文字,可指定每行的字数,文字颜色默认为白色(会覆盖原有文字)
     * 如果含有" ",默认其交互类型为 BLANK
     *
     * @param str         文字内容
     * @param columnIndex 列的下标
     * @param rowIndex    行的下标
     * @param separation  每行的字数
     * @param flagType    文字的交互类型
     */
    void setLabelsText(String str, int columnIndex, int rowIndex, int separation, int flagType) {
        setLabelsText(str, columnIndex, rowIndex, separation, flagType, Color.WHITE);
    }

    /**
     * 在指定区域的标签里设置文字,可指定文本的颜色和每行的字数(会覆盖原有文字)
     * 如果含有" ",默认其交互类型为 BLANK
     *
     * @param str         文字内容
     * @param columnIndex 列的下标
     * @param rowIndex    行的下标
     * @param separation  每行的字数
     * @param flagType    文字的交互类型
     * @param color       文字的颜色
     */
    void setLabelsText(String str, int columnIndex, int rowIndex, int separation, int flagType, Color color) {
        setLabelsText(str, columnIndex, rowIndex, separation, flagType, color, defaultFont);
    }


    /**
     * 在指定区域的标签里设置文字,可指定文本的颜色和每行的字数(会覆盖原有文字)
     * 如果含有" ",默认其交互类型为 BLANK
     *
     * @param str         文字内容
     * @param columnIndex 列的下标
     * @param rowIndex    行的下标
     * @param separation  每行的字数
     * @param flagType    文字的交互类型
     * @param color       文字的颜色
     * @param font        文字的字体
     */
    void setLabelsText(String str, int columnIndex, int rowIndex, int separation, int flagType, Color color, Font font) {
        if (str == null || str.equals("")) return;
        //每行字数不能为0或负数,行列数不能为负
        if (separation <= 0 || columnIndex < 0 || rowIndex < 0) {
            return;
        }
        //防止列数越界
        if (MAX_COLUMN - columnIndex < separation) {
            separation = MAX_COLUMN - columnIndex;
        }

        //如果字符串过长,省去后面的部分
        if (str.length() > (MAX_ROW - rowIndex) * separation) {
            str = str.substring(0, (MAX_ROW - rowIndex) * separation - 1);
        }
        //将文字拆分,并建立迭代器
        Iterator<String> words = Arrays.stream(str.split("")).iterator();

        int c_max = columnIndex + separation;
        int r_max = rowIndex + (str.length() / separation);
        if (str.length() % separation != 0) {
            //如果不能被整除,则应多一行
            r_max += 1;
        }
        //防止行数越界
        if (r_max > MAX_ROW) {
            r_max = MAX_ROW;
        }
        //当前"我"的颜色
        Color me_color = labels[me_row][me_column].getForeground();
        //当前"我"的字体
        Font me_font = labels[me_row][me_column].getFont();
        //检查"我"是否被覆盖
        boolean coveredFlag = false;
        //如果"我"被初始化了再进行检测
        if (meFLag) {
            coveredFlag = me_column >= columnIndex && me_row >= rowIndex && me_row < r_max && me_column < c_max;
            if (str.length() % separation != 0) {
                if (me_row == r_max - 1 && me_column > columnIndex + str.length() % separation - 1) {
                    coveredFlag = false;
                }
            }
        }
        //向label中插入文字
        for (int r = rowIndex; r < r_max; r++) {
            for (int c = columnIndex; c < c_max; c++) {
                String tmp = words.next();
                labels[r][c].setText(tmp);
                labels[r][c].setForeground(color);
                labels[r][c].setFont(font);
                if (tmp.equals(" ")) {
                    flags[r][c] = BLANK;
                    //如果我初始化过同时被覆盖
                    //有空隙,就插到空隙里
                    if (meFLag && coveredFlag) {
                        //因为判断为已覆盖,说明原来位置的“我”上面已经写了其他文字
                        //如果不将meFlag置为false,可能会错误的把有原来“我”所在位置的文字置空
                        meFLag = false;
                        initMe(c, r, me_color, me_font);
                        coveredFlag = false;
                    }
                } else {
                    flags[r][c] = flagType;
                }
                if (!words.hasNext()) {
                    //如果“我”被初始化且被覆盖且没有空隙插入,将其位置移至句子末尾
                    if (meFLag && coveredFlag) {
                        if (c + 1 < c_max) {
                            meFLag = false;
                            initMe(c + 1, r, me_color, me_font);
                            coveredFlag = false;
                        } else if (r + 1 < MAX_ROW) {
                            meFLag = false;
                            initMe(columnIndex, r + 1, me_color, me_font);
                            coveredFlag = false;
                        } else {
                            //如果超出屏幕,则在最后一个字的位置放置“我”
                            meFLag = false;
                            initMe(c_max - 1, MAX_ROW - 1, me_color, me_font);
                            coveredFlag = false;
                        }
                    }
                    break;
                }
            }
        }
    }


    /**
     * 初始化或立即改变“我”的位置(会清空当前记录的朝向信息,如需按方向移动请使用moveMe方法)
     * 注:在设计地图时应在摆放地图前初始化"我"的位置
     *
     * @param columnIndex 列的下标
     * @param rowIndex    行的下标
     * @param color       颜色
     */
    void initMe(int columnIndex, int rowIndex, Color color) {
        initMe(columnIndex, rowIndex, color, defaultFont);
    }

    /**
     * 初始化或立即改变“我”的位置(会清空当前记录的朝向信息,如需按方向移动请使用moveMe方法)
     * 注:在设计地图时应在摆放地图前初始化"我"的位置
     *
     * @param columnIndex 列的下标
     * @param rowIndex    行的下标
     * @param color       颜色
     * @param font        字体
     */
    void initMe(int columnIndex, int rowIndex, Color color, Font font) {
        //如果“我”已经初始化过
        if (meFLag) {
            //移除旧的”我“
            labels[me_row][me_column].setForeground(Color.WHITE);
            labels[me_row][me_column].setText(" ");
            flags[me_row][me_column] = BLANK;
        }
        //绘制新的“我”
        labels[rowIndex][columnIndex].setForeground(color);
        labels[rowIndex][columnIndex].setFont(font);
        labels[rowIndex][columnIndex].setText("我");
        flags[rowIndex][columnIndex] = BLANK;
        me_column = columnIndex;
        me_row = rowIndex;
        current_direction = 0;
        meFLag = true;
    }

    /**
     * 朝指定方向移动“我”的位置(包含对于MOVE_TEXT类型的推拉判断)
     *
     * @param direction UP:1, DOWN:2, LEFT:3, RIGHT:4
     */
    void moveMe(int direction) {
        int[] moveFlags = {MOVE_TEXT};
        moveMe(direction, moveFlags);
    }

    /**
     * 面朝位置的字符是否属于指定的类型
     *
     * @param flags 存有指定类型文字标识符的数组
     * @return 找到则返回true, 否则返回false
     */
    boolean hasFlagsFront(int[] flags) {
        int front = getFlag();
        for (int flag : flags) {
            if (flag == front) {
                return true;
            }
        }
        return false;
    }

    /**
     * 背后位置的字符是否属于指定的类型
     *
     * @param flags 存有指定类型文字标识符的数组
     * @return 找到则返回true, 否则返回false
     */
    boolean hasFlagsBehind(int[] flags) {
        int behind = getBehindFlag();
        for (int flag : flags) {
            if (flag == behind) {
                return true;
            }
        }
        return false;
    }

    /**
     * 朝指定方向移动“我”的位置,支持自定义类型的推拉判断(如还需推拉MOVE_TEXT类型,请手动添加)
     *
     * @param direction UP:1, DOWN:2, LEFT:3, RIGHT:4
     * @param moveFlags 存有可以当做推拉块对待的文字标识符的数组
     */
    void moveMe(int direction, int[] moveFlags) {
        if (meFLag) {
            //暂存当前"我"的坐标、颜色及字体
            int column = me_column, row = me_row;
            Color me_color = labels[me_row][me_column].getForeground();
            Font me_font = labels[me_row][me_column].getFont();
            //更新面朝的方向
            current_direction = direction;

            if (getFlag() == BLANK) {
                //如果前面是空白,则可移动(可能是直接前进或拉)
                if (linkedFlag) {
                    //处于连接模式,背后有可以拉的滑块,则带着滑块一起移动
                    if (hasFlagsBehind(moveFlags)) {
                        //计算拉动块的原位置
                        int old_row = row, old_column = column;
                        if (direction == UP) {
                            row -= 1;
                            old_row += 1;
                        } else if (current_direction == DOWN) {
                            row += 1;
                            old_row -= 1;
                        } else if (current_direction == LEFT) {
                            column -= 1;
                            old_column += 1;
                        } else if (current_direction == RIGHT) {
                            column += 1;
                            old_column -= 1;
                        }
                        //记录拉动块的文字、颜色、字体及flag
                        String move_text = labels[old_row][old_column].getText();
                        Color move_color = labels[old_row][old_column].getForeground();
                        Font move_font = labels[old_row][old_column].getFont();
                        int move_flag = flags[old_row][old_column];
                        //清除掉旧的拉动块
                        labels[old_row][old_column].setText(" ");
                        flags[old_row][old_column] = BLANK;
                        //在新位置上绘制拉动块(直接覆盖掉“我”)
                        labels[me_row][me_column].setForeground(move_color);
                        labels[me_row][me_column].setFont(move_font);
                        labels[me_row][me_column].setText(move_text);
                        flags[me_row][me_column] = move_flag;
                        //在新位置上绘制“我”
                        labels[row][column].setForeground(me_color);
                        labels[row][column].setFont(me_font);
                        labels[row][column].setText("我");
                        flags[row][column] = BLANK;
                        //更新坐标信息
                        me_column = column;
                        me_row = row;
                        return;
                    } else {
                        //如果没有,直接断开连接
                        linkedFlag = false;
                    }
                }  //不用else,因为断开连接后“我”仍需要移动

                //如果不处于连接模式,计算新的位置并移动
                if (direction == UP) {
                    row -= 1;
                } else if (current_direction == DOWN) {
                    row += 1;
                } else if (current_direction == LEFT) {
                    column -= 1;
                } else if (current_direction == RIGHT) {
                    column += 1;
                }
                //清除旧位置上的“我”
                labels[me_row][me_column].setText(" ");
                //在新位置上重新绘制“我”
                labels[row][column].setForeground(me_color);
                labels[row][column].setFont(me_font);
                labels[row][column].setText("我");
                //更新坐标信息
                me_column = column;
                me_row = row;

            } else if (hasFlagsFront(moveFlags) && !linkedFlag) { //处于连接模式时不可以推
                //看看滑块前是否有空间,有的话才能移动
                if (getFurtherFlag() == BLANK) {
                    int moveText_row = row, moveText_column = column;
                    if (direction == UP) {
                        row -= 1;
                        moveText_row -= 2;
                    } else if (current_direction == DOWN) {
                        row += 1;
                        moveText_row += 2;
                    } else if (current_direction == LEFT) {
                        column -= 1;
                        moveText_column -= 2;
                    } else if (current_direction == RIGHT) {
                        column += 1;
                        moveText_column += 2;
                    }
                    //记录推动块的文字、颜色、字体及flag
                    String move_text = labels[row][column].getText();
                    Color move_color = labels[row][column].getForeground();
                    Font move_font = labels[row][column].getFont();
                    int move_flag = flags[row][column];
                    //清除旧位置上的“我”
                    labels[me_row][me_column].setText(" ");
                    //在新位置上重新绘制“我”(直接覆盖掉推动块)
                    labels[row][column].setForeground(me_color);
                    labels[row][column].setFont(me_font);
                    labels[row][column].setText("我");
                    flags[row][column] = BLANK;
                    //在新位置上重新绘制推动块
                    labels[moveText_row][moveText_column].setForeground(move_color);
                    labels[moveText_row][moveText_column].setFont(move_font);
                    labels[moveText_row][moveText_column].setText(move_text);
                    flags[moveText_row][moveText_column] = move_flag;
                    //更新坐标信息
                    me_column = column;
                    me_row = row;
                }
            }
        }
    }

    /**
     * 获取现在面朝的文字的交互类型,同时起到判断边界的作用
     *
     * @return 面朝的文字的交互类型, 如越过边界, 返回TEXT:1
     */
    int getFlag() {
        int column = me_column, row = me_row;
        if (current_direction == UP) {
            if (row > 0) {
                row -= 1;
            } else return TEXT;
        } else if (current_direction == DOWN) {
            if (row < MAX_ROW - 1) {
                row += 1;
            } else return TEXT;
        } else if (current_direction == LEFT) {
            if (column > 0) {
                column -= 1;
            } else return TEXT;
        } else if (current_direction == RIGHT) {
            if (column < MAX_COLUMN - 1) {
                column += 1;
            } else return TEXT;
        }
        return flags[row][column];
    }

    /**
     * 删除当前面朝方向的文字
     */
    void deleteFront() {
        int column = me_column, row = me_row;
        //计算待删字的位置,越界则直接返回
        if (current_direction == UP) {
            if (row > 0) {
                row -= 1;
            } else return;
        } else if (current_direction == DOWN) {
            if (row < MAX_ROW - 1) {
                row += 1;
            } else return;
        } else if (current_direction == LEFT) {
            if (column > 0) {
                column -= 1;
            } else return;
        } else if (current_direction == RIGHT) {
            if (column < MAX_COLUMN - 1) {
                column += 1;
            } else return;
        }
        labels[row][column].setForeground(Color.WHITE);
        labels[row][column].setText(" ");
        flags[row][column] = 0;
    }

    /**
     * 获取现在面朝方向第二个文字的交互类型,同时起到判断边界的作用
     *
     * @return 面朝方向第二个文字的交互类型, 如越过边界, 返回TEXT:1
     */
    int getFurtherFlag() {
        int column = me_column, row = me_row;
        if (current_direction == UP) {
            if (row > 1) {
                row -= 2;
            } else return TEXT;
        } else if (current_direction == DOWN) {
            if (row < MAX_ROW - 2) {
                row += 2;
            } else return TEXT;
        } else if (current_direction == LEFT) {
            if (column > 1) {
                column -= 2;
            } else return TEXT;
        } else if (current_direction == RIGHT) {
            if (column < MAX_COLUMN - 2) {
                column += 2;
            } else return TEXT;
        }
        return flags[row][column];
    }

    /**
     * 获取背后文字的交互类型
     *
     * @return 背后文字的交互类型, 如越过边界, 返回TEXT:1
     */
    int getBehindFlag() {
        int column = me_column, row = me_row;
        if (current_direction == UP) {
            if (row < MAX_ROW - 1) {
                row += 1;
            } else return TEXT;
        } else if (current_direction == DOWN) {
            if (row > 0) {
                row -= 1;
            } else return TEXT;
        } else if (current_direction == LEFT) {
            if (column < MAX_COLUMN - 1) {
                column += 1;
            } else return TEXT;
        } else if (current_direction == RIGHT) {
            if (column > 0) {
                column -= 1;
            } else return TEXT;
        }
        return flags[row][column];
    }

    /**
     * 重置本关（时间回溯）
     */
    abstract void reset();
    /*  参考代码:
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        initMap();
        this.setVisible(true);
     */

    /**
     * 初始化地图
     * 自行添加进构造函数中
     * 地图的交互可自行添加监听器类进行实现
     */
    abstract void initMap();

}
