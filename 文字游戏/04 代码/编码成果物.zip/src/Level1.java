import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 第一关的界面,实现地图及交互
 *
 * @author 2020303122_LJX
 * @version 1.0.4
 */
public class Level1 extends Level {

    //拓展的交互类型
    private static final int WALL = 3;
    private static final int BED = 4;
    private static final int CABINET = 5;
    private static final int FIREPLACE = 6;
    private static final int DESK = 7;
    private static final int CHAIR = 8;
    private static final int PAPER = 9;
    private static final int CANDLE = 10;
    private static final int WINDOW = 11;
    private static final int DOOR = 12;
    //颜色
    private final Color wallColor = Color.WHITE;
    private final Color windowColor = new Color(50, 175, 225);
    private final Color bedColor = new Color(220, 188, 155);
    private final Color cabinetColor = new Color(140, 110, 20);
    private final Color fireplaceColor = new Color(255, 100, 0);
    private final Color deskColor = new Color(220, 188, 155);
    private final Color chairColor = new Color(220, 188, 155);
    private final Color paperColor = Color.WHITE;
    private final Color candleColor = Color.YELLOW;

    //表示是否拿走纸
    boolean paperFlag = false;
    //标明是否看完剧情
    boolean scene1_Flag = false;
    //表示剧情进行到第几步
    int scene1_step = 0;

    public Level1(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    @Override
    void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        if (!scene1_Flag) {
            scene1_step = 0;
        }
        paperFlag = false;
        initMap();
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (!scene1_Flag) {
            //剧情
            if (scene1_step == 0) {
                setLabelsText("我是文字世界的一名勇者▼", 3, 2, TEXT);
                setLabelsText("（按 空 格 键 继 续）", 9, 14, TEXT);
            } else if (scene1_step == 1) {
                setLabelsText("今天是我正式成为勇者的日子▼", 3, 5, TEXT);
            } else if (scene1_step == 2) {
                setLabelsText("为了拯救文字世界，我要取得前任勇者留下的两件神器▼", 3, 8, TEXT);
            } else if (scene1_step == 3) {
                setLabelsText("有了这两件神器，我才能够战胜恶龙▼", 3, 11, TEXT);
            } else if (scene1_step == 4) {
                clearLabels();
                setLabelsText("没时间蹉跎了！！！▼", 3, 2, TEXT);
                setLabelsText("（按 空 格 键 继 续）", 9, 14, TEXT);
            } else if (scene1_step == 5) {
                setLabelsText("据说巫师知道这两件神器的下落▼", 3, 5, TEXT);
            } else if (scene1_step == 6) {
                setLabelsText("先去找巫师问一问吧▼", 3, 8, TEXT);
            } else if (scene1_step == 7) {
                setLabelsText("想到这里，我起身下床，整装待发▼", 3, 11, TEXT);
            }
        } else {
            //地图
            clearLabels();
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙",
                    0, 0, 31, WALL, wallColor);
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙",
                    0, 15, 31, WALL, wallColor);
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 1, 1, WALL, wallColor);
            setLabelsText("墙墙墙墙墙    墙墙墙墙墙", 30, 1, 1, WALL, wallColor);
            setLabelsText("窗窗窗窗", 30, 6, 1, WINDOW, windowColor);
            setLabelsText("床床床床床床床床床床床床床床床", 3, 8, 3, BED, bedColor);
            setLabelsText("柜柜柜", 3, 14, 3, CABINET, cabinetColor);
            setLabelsText("炉", 15, 14, 1, FIREPLACE, fireplaceColor);
            setLabelsText("椅", 23, 8, 1, CHAIR, chairColor);
            setLabelsText("桌 桌桌桌 ", 22, 10, 3, DESK, deskColor);
            setLabelsText("纸", 23, 10, 1, PAPER, paperColor);
            setLabelsText("烛", 24, 11, 1, CANDLE, candleColor);
            setLabelsText(" 想起了调查物品的方法，对着物品按下空格键，就可以了解更多的信息。离开房间的出口，或许就藏在其中。", 3, 3, 25, TEXT);
            initMe(3, 3, Color.WHITE);
        }
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {
        Level1 level1;

        public MoveListener(Level1 panel) {
            this.level1 = panel;
        }

        public void keyTyped(KeyEvent e) {

        }

        /**
         * 获取指定长度的字符串,不够用空格补全,超过部分舍弃
         *
         * @param str        原字符串
         * @param separation 指定的长度
         * @return 指定长度的字符串
         */
        private String formatText(String str, int separation) {
            if (str.length() < separation) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                for (int i = str.length(); i < separation; i++) {
                    stringBuilder.append(" ");
                }
                return stringBuilder.toString();
            } else if (str.length() == separation) {
                return str;
            } else {
                return str.substring(0, separation - 1);
            }
        }

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                level1.moveMe(DOWN);
            } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                level1.moveMe(UP);
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                level1.moveMe(LEFT);
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                level1.moveMe(RIGHT);
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (!scene1_Flag) {
                    if (scene1_step < 7) {
                        scene1_step += 1;
                        initMap();
                    } else {
                        scene1_Flag = true;
                        initMap();
                    }
                }
                int flag = getFlag();
                if (flag == WALL) {
                    setLabelsText(formatText("用厚实的砖块砌成的墙，非常结实，摸起来质地粗糙。", 75),
                            3, 3, 25, TEXT);
                } else if (flag == BED) {
                    setLabelsText(formatText("木质的床，上面铺着柔软的被子，但现在可不是睡觉的时候了，抓紧时间去找巫师吧！",
                            75), 3, 3, 25, TEXT);
                } else if (flag == CABINET) {
                    setLabelsText(formatText("一个普普通通的衣柜，里面放了几件朴素的衣服。",
                            75), 3, 3, 25, TEXT);
                } else if (flag == FIREPLACE) {
                    setLabelsText(formatText("壁炉中柴火正旺，很是温暖。",
                            25), 3, 3, 25, TEXT);
                    setLabelsText(formatText("不过好像有重要的事，还是去桌上看一看好了。",
                            50), 3, 4, 25, TEXT);
                } else if (flag == DESK) {
                    setLabelsText(formatText("抽屉里，整齐排列着五花八门的文书工具。", 25),
                            3, 4, 25, TEXT);
                    setLabelsText(formatText("桌上的行事历提醒着：“准备前往集会所”",
                            25), 3, 5, 25, TEXT);
                    setLabelsText("门", 15, 4, 1, DOOR, Color.GRAY);
                    if (paperFlag) {
                        setLabelsText(formatText("工作时常用的写字桌。",
                                25), 3, 3, 25, TEXT);
                    } else {
                        setLabelsText(formatText("工作时常用的写字桌，桌上放着一张纸条。",
                                25), 3, 3, 25, TEXT);
                    }
                } else if (flag == CHAIR) {
                    setLabelsText(formatText("一把靠背椅，坐上去很舒服，但是不能坐太久。", 25),
                            3, 3, 25, TEXT);
                    setLabelsText(formatText("可惜接下来的一段时间应该没有机会再坐上去了吧。", 50),
                            3, 4, 25, TEXT);
                } else if (flag == PAPER) {
                    setLabelsText(formatText("拿起了纸，上面写着：要出去的话多留意下特殊的字吧！", 75),
                            3, 3, 25, TEXT);
                    setLabelsText("桌", 23, 10, 1, DESK, deskColor);
                    paperFlag = true;
                } else if (flag == CANDLE) {
                    setLabelsText(formatText("桌上的蜡烛燃烧着，散发着明亮的光辉。", 75),
                            3, 3, 25, TEXT);
                } else if (flag == WINDOW) {
                    setLabelsText(formatText("窗外阳光明媚，风景正好，可惜现在已经不是看风景的时候了，还是赶快去找巫师吧。", 75),
                            3, 3, 25, TEXT);
                } else if (flag == DOOR) {
                    level1.appFrame.removeListeners();
                    level1.appFrame.setWindow(new Level2(this.level1.appFrame));
                }
            } else if (e.getKeyCode() == KeyEvent.VK_L) {
                linkedFlag = !linkedFlag;
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
