import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 第二关的界面,实现地图及交互
 *
 * @author 2020303122_LJX
 * @version 1.0.3
 */
public class Level2 extends Level {

    //拓展的交互类型
    static final int ROAD1 = 3;
    static final int ROAD2 = 4;
    static final int PEOPLE = 5;
    static final int TRADER = 6;
    static final int FARMER = 7;
    static final int SOLDIER = 8;
    static final int ARTIST = 9;
    static final int WORKER = 10;

    boolean scene1_flag = false;
    boolean know_flag = false;
    boolean lost_flag = false;

    int road2_step = 0;

    public Level2(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    @Override
    void reset() {
        know_flag = scene1_flag;
        lost_flag = false;
        initMap();
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (!scene1_flag) {
            initScene1();
        } else {
            initScene2();
        }
    }

    private void initScene1() {
        clearLabels();
        Color leafColor = new Color(75, 190, 15);
        Color treeColor = new Color(150, 100, 50);
        setLabelsText("路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路", 0, 4, ROAD1);
        setLabelsText("路路路路路路路路路路路", 0, 9, ROAD1);
        setLabelsText("路路路路路路路路路路路", 20, 9, ROAD1);
        setLabelsText("路路路路路", 12, 11, 1, ROAD1);
        setLabelsText("路路路路路", 18, 11, 1, ROAD1);
        setLabelsText("路", 11, 10, ROAD1);
        setLabelsText("路", 19, 10, ROAD1);
        setLabelsText(" 叶 叶叶叶", 0, 1, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 4, 1, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 23, 1, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 28, 1, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 0, 11, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 4, 11, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 9, 11, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 19, 11, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 23, 11, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 28, 11, 3, TEXT, leafColor);
        setLabelsText("木", 1, 3, 1, TEXT, treeColor);
        setLabelsText("木", 5, 3, 1, TEXT, treeColor);
        setLabelsText("木", 24, 3, 1, TEXT, treeColor);
        setLabelsText("木", 29, 3, 1, TEXT, treeColor);
        setLabelsText("木", 1, 13, 1, TEXT, treeColor);
        setLabelsText("木", 5, 13, 1, TEXT, treeColor);
        setLabelsText("木", 10, 13, 1, TEXT, treeColor);
        setLabelsText("木", 20, 13, 1, TEXT, treeColor);
        setLabelsText("木", 24, 13, 1, TEXT, treeColor);
        setLabelsText("木", 29, 13, 1, TEXT, treeColor);
        setLabelsText("士", 5, 8, 1, SOLDIER);
        setLabelsText("农", 8, 6, 1, FARMER);
        setLabelsText("工", 16, 6, 1, WORKER);
        setLabelsText("民", 3, 5, 1, PEOPLE);
        setLabelsText("商", 19, 5, 1, TRADER);
        setLabelsText("艺", 22, 8, 1, ARTIST);
        setLabelsText("离开房间，遇到了岔路口，集会所到底在哪边呢？", 9, 1, 12, TEXT);
        initMe(15, 13, Color.WHITE);
    }

    private void initScene2() {
        clearLabels();
        Color leafColor = new Color(75, 190, 15);
        Color treeColor = new Color(150, 100, 50);
        setLabelsText("路    路", 0, 4, 1, ROAD2);
        setLabelsText("路    路", 1, 4, 1, ROAD2);
        setLabelsText("路    路", 2, 4, 1, ROAD2);
        setLabelsText("路    路", 3, 3, 1, ROAD2);
        setLabelsText("路    路", 4, 2, 1, ROAD2);
        setLabelsText("路    路", 5, 1, 1, ROAD2);
        setLabelsText("路    路", 6, 1, 1, ROAD2);
        setLabelsText("路    路", 7, 1, 1, ROAD2);
        setLabelsText("路    路", 8, 2, 1, ROAD2);
        setLabelsText("路    路", 9, 3, 1, ROAD2);
        setLabelsText("路    路", 10, 4, 1, ROAD2);
        setLabelsText("路    路", 11, 4, 1, ROAD2);
        setLabelsText("路    路", 12, 4, 1, ROAD2);
        setLabelsText("路    路", 13, 4, 1, ROAD2);
        setLabelsText("路    路", 14, 5, 1, ROAD2);
        setLabelsText("路    路", 15, 6, 1, ROAD2);
        setLabelsText("路    路", 16, 6, 1, ROAD2);
        setLabelsText("路    路", 17, 6, 1, ROAD2);
        setLabelsText("路    路", 18, 6, 1, ROAD2);
        setLabelsText("路    路", 19, 7, 1, ROAD2);
        setLabelsText("路    路", 20, 8, 1, ROAD2);
        setLabelsText("路    路", 21, 8, 1, ROAD2);
        setLabelsText("路    路", 22, 8, 1, ROAD2);
        setLabelsText("路    路", 23, 8, 1, ROAD2);
        setLabelsText("路    路", 24, 9, 1, ROAD2);
        setLabelsText("路    路", 25, 10, 1, ROAD2);
        setLabelsText("路    路", 26, 10, 1, ROAD2);
        setLabelsText("路    路", 27, 10, 1, ROAD2);
        setLabelsText("路    路", 28, 10, 1, ROAD2);
        setLabelsText("路    路", 29, 10, 1, ROAD2);
        setLabelsText("路    路", 30, 10, 1, ROAD2);
        setLabelsText(" 叶 叶叶叶", 0, 0, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 23, 0, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 28, 6, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 3, 12, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 6, 9, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 13, 13, 3, TEXT, leafColor);
        setLabelsText(" 叶 叶叶叶", 20, 5, 3, TEXT, leafColor);
        setLabelsText("木", 1, 2, 1, TEXT, treeColor);
        setLabelsText("木", 24, 2, 1, TEXT, treeColor);
        setLabelsText("木", 29, 8, 1, TEXT, treeColor);
        setLabelsText("木", 4, 14, 1, TEXT, treeColor);
        setLabelsText("木", 7, 11, 1, TEXT, treeColor);
        setLabelsText("木", 14, 15, 1, TEXT, treeColor);
        setLabelsText("木", 21, 7, 1, TEXT, treeColor);
        setLabelsText("花", 4, 10, 1, TEXT, new Color(0, 178, 255));
        setLabelsText("花", 11, 10, 1, TEXT, new Color(227, 224, 52));
        setLabelsText("花", 10, 14, 1, TEXT, new Color(103, 231, 34));
        setLabelsText("花", 18, 13, 1, TEXT, new Color(218, 95, 241));
        setLabelsText("花", 14, 1, 1, TEXT, new Color(252, 151, 84));
        setLabelsText("花", 15, 3, 1, TEXT, new Color(127, 27, 238));
        setLabelsText("花", 17, 2, 1, TEXT, new Color(0, 89, 255));
        setLabelsText("花", 26, 4, 1, TEXT, new Color(86, 192, 252));
        setLabelsText("花", 29, 1, 1, TEXT, new Color(191, 86, 252));
        initMe(0, 7, Color.WHITE);
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {

        Level2 level2;

        public MoveListener(Level2 panel) {
            this.level2 = panel;
        }

        /**
         * 获取指定长度的字符串,不够用空格补全,超过部分舍弃
         *
         * @param str        原字符串
         * @param separation 指定的长度
         * @return 指定长度的字符串
         */
        private String formatText(String str, int separation) {
            if (str.length() < separation) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                for (int i = str.length(); i < separation; i++) {
                    stringBuilder.append(" ");
                }
                return stringBuilder.toString();
            } else if (str.length() == separation) {
                return str;
            } else {
                return str.substring(0, separation - 1);
            }
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {

            if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                if (me_row == 15) {
                    setLabelsText(formatText("已经决定继续前进，又怎能回头呢？", 24),
                            9, 1, 12, TEXT);
                }
                moveMe(DOWN);
            } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                moveMe(UP);
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                if (!scene1_flag) {

                    if (me_column == 0) {
                        if (know_flag) {
                            if (lost_flag) {
                                scene1_flag = false;
                                know_flag = false;
                                lost_flag = false;
                                this.level2.appFrame.removeListeners();
                                this.level2.appFrame.setWindow(new LostEnding(this.level2.appFrame));
                            } else {
                                setLabelsText(formatText("都已经问过路了，还要执意走这边吗？", 24),
                                        9, 1, 12, TEXT);
                                lost_flag = true;
                            }
                        } else {
                            setLabelsText(formatText("还不知道集会所在哪边呢，先问一问吧！", 24),
                                    9, 1, 12, TEXT);
                        }
                    }
                } else {
                    if (me_column == 0) {
                        scene1_flag = false;
                        initMap();
                        initMe(30, 7, Color.WHITE);
                    }

                }
                moveMe(LEFT);
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                if (!scene1_flag) {
                    if (me_column == 30) {
                        if (know_flag) {
                            scene1_flag = true;
                            initMap();
                        } else {
                            setLabelsText(formatText("还不知道集会所在哪边呢，先问一问吧！", 24),
                                    9, 1, 12, TEXT);
                        }
                    }
                } else {
                    if (me_column == 30) {
                        scene1_flag = false;
                        know_flag = false;
                        lost_flag = false;
                        this.level2.appFrame.removeListeners();
                        this.level2.appFrame.setWindow(new Level3(this.level2.appFrame));
                    }
                }
                if (lost_flag) {
                    lost_flag = false;
                }
                moveMe(RIGHT);
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                int flag = getFlag();
                if (flag == SOLDIER) {
                    know_flag = true;
                    setLabelsText(formatText("你要去集会所是吧？往东走就行了。", 24),
                            9, 1, 12, TEXT);
                } else if (flag == FARMER) {
                    setLabelsText(formatText("说出口的字句，好像风一吹就散开的云。", 24),
                            9, 1, 12, TEXT);
                } else if (flag == WORKER) {
                    setLabelsText(formatText("记住一件事：役圣器，而不役于圣器。", 24),
                            9, 1, 12, TEXT);
                } else if (flag == TRADER) {
                    setLabelsText(formatText("要不要买个勇者徽章呢？算你八折就好。", 24),
                            9, 1, 12, TEXT);
                } else if (flag == PEOPLE) {
                    setLabelsText(formatText("大家都会在未来等你，别担心，出发吧。", 24),
                            9, 1, 12, TEXT);
                } else if (flag == ARTIST) {
                    setLabelsText(formatText("所谓旅程，其实不过是预先写好的结局。", 24),
                            9, 1, 12, TEXT);
                } else if (flag == ROAD1) {
                    setLabelsText(formatText("路边有一些闲适的人，或许可以找他们问问路。", 24),
                            9, 1, 12, TEXT);
                } else if (flag == ROAD2) {
                    road2_step = (road2_step + 1) % 3;
                    if (road2_step == 0) {
                        setLabelsText(formatText("  别在路上耽搁太多时间。", 15),
                                8, 0, TEXT);
                    } else if (road2_step == 1) {
                        setLabelsText(formatText("天气真好，脚步也变得轻盈起来。", 15),
                                8, 0, TEXT);
                    } else if (road2_step == 2) {
                        setLabelsText(formatText("  让巫师等久了就不好了。", 15),
                                8, 0, TEXT);
                    }
                }
            } else if (e.getKeyCode() == KeyEvent.VK_L) {
                linkedFlag = !linkedFlag;
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
