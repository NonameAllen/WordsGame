import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 第三关的界面,实现地图及交互
 *
 * @author 2020303118_CLY
 * @author (fixed by 2020303122_LJX)
 * @version 1.0.2
 */
public class Level3 extends Level {

    // 拓展的交互类型
    static final int ROAD = 3;
    static final int HOUSE = 4;
    static final int DOOR = 5;
    static final int DOOR0 = 11;
    static final int DOOR1 = 12;
    static final int WALL = 6;
    static final int DESK = 7;
    static final int CHAIR = 8;
    static final int FLOWER = 9;
    static final int WITCHER = 10;
    static final int LIGHT = 13;

    int scene = 0;

    boolean road1Flag = false;
    boolean roomFlag = false;
    boolean road2Flag = false;

    public Level3(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (scene == 0) {
            clearLabels();
            road1Flag = true;
            roomFlag = false;
            road2Flag = false;
            setLabelsText("路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路", 0, 15, ROAD);
            setLabelsText("路路路路路路路路铺门铺路路路路路路站门站路路路路路所门所路路路", 0, 10, ROAD);
            setLabelsText("铺门铺", 8, 10, HOUSE);
            setLabelsText("门", 9, 10, DOOR0);
            setLabelsText("站门站", 17, 10, HOUSE);
            setLabelsText("门", 18, 10, DOOR0);
            setLabelsText("所门所", 25, 10, HOUSE);
            setLabelsText("门", 26, 10, 1, DOOR, Color.GRAY);
            setLabelsText("铺铺铺铺铺     站站站    所所所所所", 7, 9, HOUSE);
            setLabelsText("铺铺铺匠铺铺铺   站站修站站  所所所会所所所", 6, 8, HOUSE);
            setLabelsText("铺铺铁铺铺     站维站    所所集所所", 7, 7, HOUSE);
            setLabelsText("铺铺铺       站      所所所", 8, 6, HOUSE);
            setLabelsText("铺                所", 9, 5, HOUSE);
            setLabelsText("铁匠铺", 9, 7, 1, HOUSE, Color.BLUE);
            setLabelsText("维修站", 18, 7, 1, HOUSE, Color.BLUE);
            setLabelsText("集会所", 26, 7, 1, HOUSE, Color.BLUE);
            initMe(0, 12, Color.WHITE);
        } else if (scene == 1) {
            clearLabels();
            road1Flag = false;
            roomFlag = true;
            road2Flag = false;
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 0, MAX_COLUMN, WALL);
            setLabelsText("灯灯灯 ", 1, 2, 2, LIGHT, Color.ORANGE);
            setLabelsText("灯灯 灯", 28, 2, 2, LIGHT, Color.ORANGE);
            setLabelsText("灯 灯灯", 1, 13, 2, LIGHT, Color.ORANGE);
            setLabelsText(" 灯灯灯", 28, 13, 2, LIGHT, Color.ORANGE);
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 2, 1, WALL);
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙", 30, 2, 1, WALL);
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙门墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 15, MAX_COLUMN, WALL);
            setLabelsText("门", 14, 15, 1, DOOR, Color.GRAY);
            setLabelsText("椅 椅", 4, 3, CHAIR);
            setLabelsText("椅 椅", 24, 3, CHAIR);
            setLabelsText("椅 椅", 4, 11, CHAIR);
            setLabelsText("椅 椅", 24, 11, CHAIR);
            setLabelsText("椅 椅 椅", 2, 5, 1, CHAIR);
            setLabelsText("椅 椅 椅", 8, 5, 1, CHAIR);
            setLabelsText("椅 椅 椅", 22, 5, 1, CHAIR);
            setLabelsText("椅 椅 椅", 28, 5, 1, CHAIR);
            setLabelsText("桌桌桌桌桌桌桌桌桌桌桌桌桌桌桌", 4, 5, 3, DESK);
            setLabelsText("桌桌桌桌桌桌桌桌桌桌桌桌桌桌桌", 24, 5, 3, DESK);
            setLabelsText("花", 11, 12, 1, FLOWER, Color.YELLOW);
            setLabelsText("盆", 11, 13, 1, FLOWER, Color.GREEN);
            setLabelsText("花", 17, 12, 1, FLOWER, Color.YELLOW);
            setLabelsText("盆", 17, 13, 1, FLOWER, Color.GREEN);
            setLabelsText("巫", 14, 7, 1, WITCHER, Color.RED);
            setLabelsText("我", 14, 13, BLANK);
            setLabelsText("「······」 ▼", 10, 3, 11, TEXT);

        } else if (scene == 2) {
            setLabelsText("巫师：「命中注定之人啊，我终于等到你了！」▼           ", 10, 3, 11, TEXT);
        } else if (scene == 3) {
            setLabelsText("巫师挥舞起法杖，「不过我的使命也该结束了···」▼        ", 10, 3, 11, TEXT);
        } else if (scene == 4) {
            setLabelsText("巫师：「剩下的交给你了，我相信你的力量，未来的屠龙勇者啊」▼   ", 10, 3, 11, TEXT);
        } else if (scene == 5) {
            setLabelsText("我：「巫师大人，您怎么了？我又该做什么？」▼             ", 10, 3, 11, TEXT);
        } else if (scene == 6) {
            setLabelsText("巫师：「踏上你的征途吧，勇者，去寻找屠龙的圣器！」▼       ", 10, 3, 11, TEXT);
        } else if (scene == 7) {
            setLabelsText("巫师说完停下了手中的法杖，闭上了眼▼               ", 10, 3, 11, TEXT);
            setLabelsText("我：「······」▼", 10, 5, 11, TEXT);
        } else if (scene == 8) {
            clearLabels();
            initMe(14, 13, Color.WHITE);
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 0, MAX_COLUMN, WALL);
            setLabelsText("灯灯灯 ", 1, 2, 2, LIGHT, Color.ORANGE);
            setLabelsText("灯灯 灯", 28, 2, 2, LIGHT, Color.ORANGE);
            setLabelsText("灯 灯灯", 1, 13, 2, LIGHT, Color.ORANGE);
            setLabelsText(" 灯灯灯", 28, 13, 2, LIGHT, Color.ORANGE);
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 2, 1, WALL);
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙", 30, 2, 1, WALL);
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙门墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 15, MAX_COLUMN, WALL);
            setLabelsText("门", 14, 15, 1, DOOR, Color.GRAY);
            setLabelsText("椅 椅", 4, 3, CHAIR);
            setLabelsText("椅 椅", 24, 3, CHAIR);
            setLabelsText("椅 椅", 4, 11, CHAIR);
            setLabelsText("椅 椅", 24, 11, CHAIR);
            setLabelsText("椅 椅 椅", 2, 5, 1, CHAIR);
            setLabelsText("椅 椅 椅", 8, 5, 1, CHAIR);
            setLabelsText("椅 椅 椅", 22, 5, 1, CHAIR);
            setLabelsText("椅 椅 椅", 28, 5, 1, CHAIR);
            setLabelsText("桌桌桌桌桌桌桌桌桌桌桌桌桌桌桌", 4, 5, 3, DESK);
            setLabelsText("桌桌桌桌桌桌桌桌桌桌桌桌桌桌桌", 24, 5, 3, DESK);
            setLabelsText("花", 11, 12, 1, FLOWER, Color.YELLOW);
            setLabelsText("盆", 11, 13, 1, FLOWER, Color.GREEN);
            setLabelsText("花", 17, 12, 1, FLOWER, Color.YELLOW);
            setLabelsText("盆", 17, 13, 1, FLOWER, Color.GREEN);
            setLabelsText("巫", 14, 7, 1, WITCHER, Color.RED);
        } else if (scene == 9) {
            clearLabels();
            road1Flag = false;
            roomFlag = false;
            road2Flag = true;
            setLabelsText("路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路", 0, 15, ROAD);
            setLabelsText("路路路路路路路路铺门铺路路路路路路站门站路路路路路所门所路路路", 0, 10, ROAD);
            setLabelsText("铺门铺", 8, 10, HOUSE);
            setLabelsText("门", 9, 10, 1, DOOR, Color.GRAY);
            setLabelsText("站门站", 17, 10, HOUSE);
            setLabelsText("门", 18, 10, DOOR1);
            setLabelsText("所门所", 25, 10, HOUSE);
            setLabelsText("门", 26, 10, DOOR1);
            setLabelsText("铺铺铺铺铺     站站站    所所所所所", 7, 9, HOUSE);
            setLabelsText("铺铺铺匠铺铺铺   站站修站站  所所所会所所所", 6, 8, HOUSE);
            setLabelsText("铺铺铁铺铺     站维站    所所集所所", 7, 7, HOUSE);
            setLabelsText("铺铺铺       站      所所所", 8, 6, HOUSE);
            setLabelsText("铺                所", 9, 5, HOUSE);
            setLabelsText("铁匠铺", 9, 7, 1, HOUSE, Color.BLUE);
            setLabelsText("维修站", 18, 7, 1, HOUSE, Color.BLUE);
            setLabelsText("集会所", 26, 7, 1, HOUSE, Color.BLUE);
            initMe(26, 11, Color.WHITE);
        }
    }

    /**
     * 重置本关（时间回溯） 必要时进行覆写
     */
    @Override
    public void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        if (road1Flag) {
            scene = 0;
        } else if (roomFlag) {
            scene = 1;
        } else if (road2Flag) {
            scene = 9;
        }
        initMap();
        this.setVisible(true);
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {
        Level3 level3;

        public MoveListener(Level3 panel) {
            this.level3 = panel;
        }

        public void keyTyped(KeyEvent e) {

        }

        /**
         * 获取指定长度的字符串,不够用空格补全,超过部分舍弃
         *
         * @param str        原字符串
         * @param separation 指定的长度
         * @return 指定长度的字符串
         */
        private String formatText(String str, int separation) {
            if (str.length() < separation) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                for (int i = str.length() - 1; i < separation; i++) {
                    stringBuilder.append(" ");
                }
                return stringBuilder.toString();
            } else if (str.length() == separation) {
                return str;
            } else {
                return str.substring(0, separation - 1);
            }
        }

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                level3.moveMe(DOWN);
            } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                level3.moveMe(UP);
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                if (meFLag && level3.me_column == 0) {
                    setLabelsText(formatText("开弓没有回头箭！！！", 25), 1, 1, TEXT);
                }
                level3.moveMe(LEFT);
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                if (meFLag && level3.me_column == 30) {
                    setLabelsText(formatText("只有取得两件圣器才有力量打败恶龙吧！", 25), 1, 1, TEXT);
                }
                level3.moveMe(RIGHT);
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (level3.scene > 0 && level3.scene <= 7) {
                    level3.scene += 1;
                    initMap();
                } else {
                    int flag = getFlag();
                    if (flag == ROAD) {
                        setLabelsText(formatText("我有预感，路边的有一栋建筑就是我将要去的地方。", 25), 1, 1, TEXT);
                    } else if (flag == HOUSE) {
                        setLabelsText(formatText("这间房屋内有不同寻常的力量···", 25), 1, 1, TEXT);
                    } else if (flag == DOOR0) {
                        setLabelsText(formatText("现在还不是时候。", 25), 1, 1, TEXT);
                    } else if (flag == DOOR1) {
                        setLabelsText(formatText("我接下来应该去···哪儿来着？", 25), 1, 1, TEXT);
                    } else if (flag == DOOR) {
                        if (level3.scene == 8) {
                            level3.clearLabels();
                            level3.scene = 9;
                            initMap();
                        } else if (level3.scene < 1) {
                            level3.clearLabels();
                            level3.scene = 1;
                            initMap();
                        } else if (level3.scene == 9) {
                            level3.appFrame.removeListeners();
                            level3.appFrame.setWindow(new Level4_1(this.level3.appFrame));
                        }
                    } else if (flag == WALL) {
                        setLabelsText(formatText("找到出口就出去吧！", 25), 10, 3, 11, TEXT);
                    } else if (flag == DESK) {
                        setLabelsText(formatText("这时候，桌上有美味的大餐就好了。", 25), 10, 3, 11, TEXT);
                    } else if (flag == CHAIR) {
                        setLabelsText(formatText("坐得太久，会连走路都忘了吧。", 25), 10, 3, 11, TEXT);
                    } else if (flag == FLOWER) {
                        setLabelsText(formatText("但愿改日归来之时，能够看见繁花盛开。", 25), 10, 3, 11, TEXT);
                    } else if (flag == WITCHER) {
                        setLabelsText(formatText("我会注视着你，未来也在等你！", 25), 10, 3, 11, TEXT);
                    } else if (flag == LIGHT) {
                        setLabelsText(formatText("嗯~造型独特的壁灯。", 25), 10, 3, 11, TEXT);
                    }
                }
            } else if (e.getKeyCode() == KeyEvent.VK_L) {
                linkedFlag = !linkedFlag;
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
