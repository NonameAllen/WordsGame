import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 进入铁铺之后的界面,实现地图及交互
 *
 * @author 2020303140_QZ
 * @author (fixed by 2020303122_LJX)
 * @version 1.0.4
 */
public class Level4_1 extends Level {

    // 拓展的交互类型
    static final int NO = 4;
    static final int SWORD = 5; // 剑
    static final int FIRE = 6; // 火炬
    static final int STONE = 7; // 石、岩、磊
    static boolean moveFlag = true; // 表示此时可不可以移动（在提示的结尾有“▼”时不可以移动）。
    static boolean ifFirst = true; // 标识是否是第一次
    int scene;

    boolean getDeleteFlag = false;
    boolean beforeRoomFlag = false;
    boolean roomFlag = false;

    public Level4_1(AppFrame frame) {
        super(frame);
        scene = 0;
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 时间回溯
     */
    void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;

        ifFirst = true;
        getDeleteFlag = false;
        if (beforeRoomFlag) {
            scene = 0;
        } else if (roomFlag) {
            scene = 8;
        }

        initMap();
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (scene == 0) {
            moveFlag = false;
            setLabelsText("走进铁铺，果然看到墙上挂着琳琅满目的兵器。", 3, 3, TEXT);
            setLabelsText("但我心里很清楚，贝克斯贝剑不在其中▼", 3, 4, TEXT);
            setLabelsText("（按 空 格 键 继 续）", 9, 13, TEXT);
        } else if (scene == 1) {
            beforeRoomFlag = true;
            roomFlag = false;
            setLabelsText("【勇者来啦，这么早！】说话的人是博德导师，", 3, 8, TEXT);
            setLabelsText("“听他这爽朗的语气，大概不会给我太难的试炼▼", 3, 9, TEXT);
        } else if (scene == 2) {
            clearLabels();
            setLabelsText("（按 空 格 键 继 续）", 9, 13, TEXT);
            setLabelsText("【我刚才又将贝克思贝斯之剑仔细擦拭了一遍。】  ", 3, 3, TEXT);
            setLabelsText("“博德说：【试炼也已经准备就绪，就等着你来。】▼  ", 3, 4, TEXT);
        } else if (scene == 3) {
            setLabelsText("德博拉开货架后方的暗门，转眼就不见了踪影。", 4, 8, TEXT);
            setLabelsText("我乖乖地跟着走进去，踏入一片黑漆漆的空间。▼  ", 4, 9, TEXT);
        } else if (scene == 4) {
            clearLabels();
            setLabelsText("在一片黑暗中，一撮火焰悠悠燃起。", 3, 2, TEXT);
            setLabelsText("借着微光，仿佛能够看到一条石砖道。", 3, 3, TEXT);
            setLabelsText("以及远方一座山丘。▼", 3, 4, TEXT);
            setLabelsText("火", 5, 7, TEXT);
            setLabelsText("炬", 5, 8, TEXT);
            setLabelsText("我", 3, 9, TEXT);
        } else if (scene == 5) {
            setLabelsText("忽然间，一座座火炬被点亮，       ", 3, 2, TEXT);
            setLabelsText("远方的石冢山丘也清晰可见。▼             ", 3, 3, TEXT);
            setLabelsText("               ", 3, 4, BLANK);
            setLabelsText("           ", 9, 13, TEXT);
            setLabelsText("磊磊磊岩岩岩石石石", 16, 7, STONE);
            setLabelsText("磊磊岩岩岩石石", 17, 6, STONE);
            setLabelsText("磊岩岩岩石", 18, 5, STONE);
            setLabelsText("岩岩岩   岩岩岩", 16, 8, STONE);
            setLabelsText("火   火   火", 5, 7, 9, FIRE, Color.RED);
            setLabelsText("炬   炬   炬", 5, 8, 9, FIRE, Color.WHITE);
            setLabelsText("火   火   火", 5, 10, 9, FIRE, Color.RED);
            setLabelsText("炬   炬   炬", 5, 11, 9, FIRE, Color.WHITE);
            setLabelsText("岩岩岩", 22, 9, 3, STONE);
            setLabelsText("岩岩岩   岩岩岩", 16, 10, STONE);
            setLabelsText("石石石岩岩岩磊磊磊", 16, 11, STONE);
            setLabelsText("石石岩岩岩磊磊", 17, 12, STONE);
            setLabelsText("石岩岩岩磊", 18, 13, STONE);
        } else if (scene == 6) {
            setLabelsText("前面出现一座石头堆叠而成的小丘。     ", 3, 2, TEXT);
            setLabelsText("石丘上插着那把贝克思贝斯之剑。▼            ", 3, 3, TEXT);
            setLabelsText("我", 3, 9, TEXT);
            setLabelsText("剑", 20, 9, 1, SWORD, Color.YELLOW);
            setLabelsText("岩岩岩", 22, 9, 3, STONE);
        } else if (scene == 7) {
            setLabelsText("                   ", 3, 2, BLANK);
            setLabelsText("                   ", 3, 3, BLANK);
            setLabelsText("如果师傅说的没错,          ", 3, 1, TEXT);
            setLabelsText("有了这一件圣器，就能删去不怀好意的字。▼            ", 3, 2, TEXT);
        } else if ((scene == 8) && (!meFLag)) {
            clearLabels();
            beforeRoomFlag = false;
            roomFlag = true;
            setLabelsText(" ", 3, 9, BLANK);
            setLabelsText("如果师傅说的没错，", 3, 1, TEXT);
            setLabelsText("有了这一件圣器，就能删去不怀好意的字。 ", 3, 2, TEXT);
            setLabelsText("磊磊磊岩岩岩石石石", 16, 7, STONE);
            setLabelsText("磊磊岩岩岩石石", 17, 6, STONE);
            setLabelsText("磊岩岩岩石", 18, 5, STONE);
            setLabelsText("岩岩岩   岩岩岩", 16, 8, STONE);
            setLabelsText("火   火   火", 5, 7, 9, FIRE, Color.RED);
            setLabelsText("炬   炬   炬", 5, 8, 9, FIRE, Color.WHITE);
            setLabelsText("火   火   火", 5, 10, 9, FIRE, Color.RED);
            setLabelsText("炬   炬   炬", 5, 11, 9, FIRE, Color.WHITE);
            setLabelsText("剑", 20, 9, 1, SWORD, Color.YELLOW);
            setLabelsText("岩岩岩", 22, 9, 3, STONE);
            setLabelsText("岩岩岩   岩岩岩", 16, 10, STONE);
            setLabelsText("石石石岩岩岩磊磊磊", 16, 11, STONE);
            setLabelsText("石石岩岩岩磊磊", 17, 12, STONE);
            setLabelsText("石岩岩岩磊", 18, 13, STONE);
            initMe(3, 9, Color.white);
            moveFlag = true; // 此时“我”可以运动。
        }

    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {
        Level4_1 level4_1;

        public MoveListener(Level4_1 panel) {
            this.level4_1 = panel;
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {
            int flag = getFlag();
            if ((e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) && moveFlag) {
                level4_1.moveMe(DOWN);
            } else if ((e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) && moveFlag) {
                level4_1.moveMe(UP);
            } else if ((e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) && moveFlag) {
                level4_1.moveMe(LEFT);
            } else if ((e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) && moveFlag) {
                level4_1.moveMe(RIGHT);
            } else if (e.getKeyCode() == KeyEvent.VK_K) { // 如果按下删除键
                if (flag == NO) {
                    setLabelsText(" ", 14, 4, BLANK);
                    initMe(12, 4, Color.WHITE);
                    setLabelsText("握着这沉重的剑身， 停下了身体的颤抖。            ", 3, 4, TEXT);
                    setLabelsText("【斩去心中的害怕，是成为勇者的第一步。】          ", 3, 1, TEXT);
                    setLabelsText("博德十分满意地说。▼            ", 3, 2, TEXT);
                    moveFlag = false;
                    scene = 13;
                    setLabelsText("                    ", 2, 15, TEXT);
                } else if (getDeleteFlag) {
                    setLabelsText("这把刀十分的珍贵，不应该毫无章法地使用。     ", 2, 15, TEXT);
                }
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (level4_1.scene <= 7) {
                    level4_1.scene += 1;
                    initMap();

                } else if (level4_1.scene == 8) {
                    initMap();
                } else if (scene == 9) {
                    setLabelsText("【圣剑--贝克思贝斯之剑，又称帝利特之剑。】         ", 3, 1, TEXT);
                    setLabelsText("博德那明亮的噪音回荡在黑暗之中。▼            ", 3, 2, TEXT);
                    setLabelsText(" ", 20, 9, BLANK);
                    scene = 10;
                    moveFlag = false;
                } else if (scene == 10) {
                    setLabelsText("【按下“K键”便能够删除不该存在的字。          ", 3, 1, TEXT);
                    setLabelsText("拿起这剑，斩去你心中的疑惑和害怕吧。】▼            ", 3, 2, TEXT);
                    scene = 11;
                    getDeleteFlag = true;
                } else if (scene == 11) {
                    setLabelsText("握着这沉重的剑身， 停不下身体的颤抖。▼            ", 3, 4, TEXT);
                    initMe(12, 4, Color.WHITE);
                    meFLag = false;
                    scene = 12;
                } else if (scene == 12) {
                    setLabelsText("握着这沉重的剑身， 停 下身体的颤抖。            ", 3, 4, TEXT);
                    setLabelsText("不", 14, 4, NO);
                    if (ifFirst) {
                        initMe(12, 4, Color.WHITE);
                        ifFirst = false;
                    }
                    moveFlag = true;
                } else if (scene == 13) {
                    clearLabels();
                    setLabelsText("【在以后的旅程中，你终将面对无数的文字，有的", 3, 5, TEXT);
                    setLabelsText("无法撼动，有的蕴含恶意，有的则是深藏转机。】▼", 3, 6, TEXT);
                    moveFlag = false;
                    scene = 14;
                } else if (scene == 14) {
                    setLabelsText("【而作为识字勇者，你的责任就是找出那些转机，", 3, 9, TEXT);
                    setLabelsText("并以圣剑的力量将命运改写。】▼ ", 3, 10, TEXT);
                    scene = 15;
                } else if (scene == 15) {
                    clearLabels();
                    setLabelsText("【如果你是真正的识字勇者，           ", 3, 6, TEXT);
                    setLabelsText("必定能够以手中之剑，开创出条道路的。】▼             ", 3, 7, TEXT);
                    scene = 16;
                } else if (scene == 16) {
                    clearLabels();
                    setLabelsText("就在下个瞬间，火炬全部熄灭。         ", 3, 5, TEXT);
                    setLabelsText("石丘开始崩塌，地面也开始剧烈摇晃。            ", 3, 6, TEXT);
                    setLabelsText("黑暗与失重感同时袭来▼ ", 3, 8, TEXT);
                    scene = 17;
                } else if (scene >= 17 && scene <= 20) {
                    clearLabels();
                    String str =
                            "岩窟窟窟窟                    岩窟窟窟窟窟岩" + "岩窟窟窟                     岩窟窟窟岩窟" +
                                    "岩窟窟窟窟                    岩窟窟窟岩窟" + "岩窟窟                      岩窟窟窟岩窟" +
                                    "岩窟窟                    岩窟岩岩窟窟窟岩" + "岩窟                   窟岩岩岩岩窟窟窟岩窟" +
                                    "岩窟窟                   窟岩岩岩岩窟窟窟岩" + "岩窟窟窟                   窟岩岩岩窟窟窟岩" +
                                    "岩窟                      岩岩岩窟窟窟岩" + "岩窟窟                      岩岩窟窟窟岩" +
                                    "岩窟窟窟窟                    岩岩窟窟窟岩" + "岩窟窟窟                    岩岩岩窟窟窟岩" +
                                    "岩窟窟                        窟窟窟岩" + "岩窟窟窟窟                       窟窟岩" +
                                    "岩窟                       岩岩窟窟窟";
                    setLabelsText(str, 0, 1, MAX_COLUMN, TEXT);
                    if (scene == 17) {
                        setLabelsText("我", 11, 3, TEXT);
                        setLabelsText("不断往下掉▼", 12, 4, TEXT);
                    } else if (scene == 18) {
                        setLabelsText(" ", 11, 3, TEXT);
                        setLabelsText("       ", 12, 4, TEXT);
                        setLabelsText("不知道 还会坠落多久▼", 8, 8, TEXT);
                        setLabelsText("我", 11, 8, TEXT);
                    } else if (scene == 19) {
                        setLabelsText("这是要死了吗？▼", 12, 11, TEXT);
                        setLabelsText("我", 11, 12, TEXT);
                        setLabelsText("             ", 8, 8, TEXT);
                        setLabelsText(" ", 11, 9, TEXT);
                    } else if (scene == 20) {
                        clearLabels();
                    }
                    scene += 1;
                } else if (scene == 21) {
                    level4_1.appFrame.removeListeners();
                    level4_1.appFrame.setWindow(new Level4_2(this.level4_1.appFrame));
                }
                if ((flag == SWORD) && moveFlag) {
                    setLabelsText("我轻轻拔起贝克思贝斯之剑。               ", 3, 1, TEXT);
                    setLabelsText("感觉意志力注入体内。▼            ", 3, 2, TEXT);
                    moveFlag = false;
                    scene = 9;
                } else if ((flag == STONE) && moveFlag) {
                    setLabelsText("乱石磊磊，小心为上。     ", 2, 15, TEXT);
                } else if ((flag == FIRE) && moveFlag) {
                    setLabelsText("充满光热的地方，令人想要靠近。      ", 2, 15, TEXT);
                }
            }
        }

        public void keyReleased(KeyEvent e) {
        }
    }
}