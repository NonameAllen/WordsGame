import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 进入铁铺并掉入悬崖之后的剧情，实现地图及交互
 *
 * @author 2020303140_QZ
 * @author (fixed by 2020303122_LJX)
 * @version 1.0.4
 */
public class Level4_2 extends Level {
    // 拓展的交互类型
    static final int NO = 4;
    static final int DOOR = 5;
    static final int STONE = 6;
    static boolean moveFlag = false; // 表示此时可不可以移动（在提示的结尾有“▼”时不可以移动）。
    int scene; // 表示进行交互的场景的编号（在该图只有0-4）
    int tipsStep = 0;

    boolean roomFlag = false;

    public Level4_2(AppFrame frame) {
        super(frame);
        scene = 0;
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 时间回溯
     */
    void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        if (roomFlag) {
            scene = 1;
        } else {
            scene = 0;
        }
        initMap();
        this.setVisible(true);
        moveFlag = false;

    }

    /**
     * 绘制背景的石窟
     */
    void initMap2() {
        clearLabels();
        String[] str = {"岩窟岩窟窟窟岩窟窟窟窟窟岩窟窟岩窟窟窟窟岩岩窟窟窟岩岩窟窟岩", "岩窟窟窟窟岩岩窟窟窟窟窟岩窟窟窟岩窟窟窟岩岩窟窟窟岩岩窟窟岩",
                "岩窟窟窟窟岩岩窟窟窟窟窟岩窟窟窟岩窟窟窟岩岩窟窟窟岩岩窟窟岩", "岩窟窟窟窟岩窟窟窟窟          岩岩窟窟窟岩岩窟窟岩", "岩窟窟窟窟岩窟窟              窟窟窟岩岩窟窟岩",
                "岩窟窟窟窟                    岩岩窟窟岩", "岩窟窟窟                      岩窟窟岩", "岩窟窟                        窟窟岩"};
        for (int i = 0; i < 8; i++) {
            setLabelsText(str[i], 0, i, STONE);
        }
        for (int i = 0; i < 8; i++) {
            setLabelsText(str[i], 0, 15 - i, STONE);
        }

    }

    /**
     * 绘制背景的石窟
     */
    void initMap1() {
        clearLabels();
        String[] str = {"岩窟窟窟窟岩窟窟岩窟窟岩窟窟窟窟岩窟窟窟窟窟岩窟窟窟岩岩窟窟岩", "岩窟窟窟窟岩窟窟窟窟窟岩窟窟窟窟岩窟窟窟窟岩岩窟窟窟岩岩窟窟岩",
                "岩窟窟窟窟岩窟窟窟窟窟岩窟岩岩窟岩窟窟窟窟岩岩窟窟窟窟岩窟窟岩", "岩窟窟窟窟岩窟窟岩窟窟岩窟窟窟窟岩窟窟窟窟窟岩窟窟窟岩岩窟窟岩", "岩窟窟窟窟岩窟窟窟窟窟岩窟窟窟窟岩窟窟窟窟岩岩窟窟窟岩岩窟窟岩",
                "岩窟窟窟窟岩窟窟窟窟窟岩窟岩岩窟岩窟窟窟窟岩岩窟窟窟窟岩窟窟岩", "岩窟窟窟窟岩窟窟窟窟窟岩窟窟窟窟岩窟窟窟窟岩岩窟窟窟岩岩窟窟岩",
                "岩窟窟窟窟岩窟窟窟窟窟岩窟岩岩窟岩窟窟窟窟岩岩窟窟窟窟岩窟窟岩"};
        for (int i = 0; i < 8; i++) {
            setLabelsText(str[i], 0, i, TEXT);
        }
        for (int i = 0; i < 8; i++) {
            setLabelsText(str[i], 0, 15 - i, TEXT);
        }
    }

    /**
     * 对地图初始化，根据scene选择不同的场景
     */
    void initMap() {
        if (scene == 0) {
            initMap1();
        } else if (scene == 1) {
            roomFlag = true;
            initMap2();
        } else if (scene == 2) {
            setLabelsText("我睁开眼睛……", 9, 7, TEXT);
            setLabelsText("坚硬的岩壁环绕着四周。▼ ", 9, 8, TEXT);
        } else if (scene == 3) {
            setLabelsText("我惊讶地发现自己并没有摔死，", 9, 7, TEXT);
            setLabelsText("而这里似乎没有一条缝隙。▼ ", 9, 8, TEXT);
        } else if (scene == 4) {
            setLabelsText(" 惊讶地发现自己并没有摔死,", 9, 7, TEXT);
            setLabelsText("而这里似乎 有一条缝隙。", 9, 8, TEXT);
            initMe(9, 7, Color.WHITE);
            setLabelsText("没", 14, 8, NO);
            moveFlag = true;
        }

    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {
        Level4_2 level4_2;

        public MoveListener(Level4_2 panel) {
            this.level4_2 = panel;
        }

        public void keyTyped(KeyEvent e) {

        }

        /**
         * 按下按键后，根据具体的按键实现对应的操作。
         * 对玩家进行剧情提示时，不允许“我”移动，这时moveFlag为false，需要移动时，moveFlag为true，这时玩家可以移动。
         */
        public void keyPressed(KeyEvent e) {
            if ((e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) && moveFlag) {
                level4_2.moveMe(DOWN);
            } else if ((e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) && moveFlag) {
                level4_2.moveMe(UP);
            } else if ((e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) && moveFlag) {
                level4_2.moveMe(LEFT);
            } else if ((e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) && moveFlag) {
                if (me_row == 8 && me_column == 29) {
                    level4_2.appFrame.removeListeners();
                    level4_2.appFrame.setWindow(new Level5(this.level4_2.appFrame)); // 在这里离开铁匠铺，进入下一个场景
                }
                level4_2.moveMe(RIGHT);
            } else if ((e.getKeyCode() == KeyEvent.VK_K) && moveFlag) {
                int flag = getFlag();
                if ((flag == NO) && moveFlag) {
                    setLabelsText(" ", 15, 10, BLANK);
                    setLabelsText("岩窟窟      而这里似乎 有一条缝隙。         ", 0, 8, TEXT);
                    setLabelsText(" ", 29, 8, DOOR);
                    setLabelsText("             ", 10, 10, TEXT);
                }
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (scene <= 4) {
                    scene = scene + 1;
                    initMap();

                }
                int flag = getFlag();
                if ((flag == STONE) && moveFlag) {
                    tipsStep = (tipsStep + 1) % 3;
                    if (tipsStep == 0) {
                        setLabelsText("除非有一些多余的结构…", 10, 10, TEXT);
                    } else if (tipsStep == 1) {
                        setLabelsText(" 想想怎么才能出去吧 ", 10, 10, TEXT);
                    } else if (tipsStep == 2) {
                        setLabelsText("试试贝克思贝斯之剑吧！", 10, 10, TEXT);
                    }
                }
            }
        }

        public void keyReleased(KeyEvent e) {
        }
    }

}