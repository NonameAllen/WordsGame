import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 第五关的界面,实现地图及交互
 *
 * @author 2020303118_CLY
 * @version 1.0.1
 */
public class Level5 extends Level {

    // 拓展的交互类型
    static final int ROAD = 3;
    static final int HOUSE = 4;
    static final int DOOR = 5;
    static final int DOOR0 = 6;
    static final int DOOR1 = 7;
    static final int WALL = 8;
    static final int CAGE = 9;
    static final int BED = 10;
    static final int BOX = 11;
    static final int PEOPLE = 12;
    static final int WINDOW = 13;
    static final int LIGHT = 14;
    static final int KEY = 15;
    static final int OPEN = 16;
    static final int SWORD = 17;

    boolean sword = false;

    int scene;

    int[] moveFlags = {BOX};

    public Level5(AppFrame frame) {
        super(frame);
        scene = 1;
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (scene == 0) {
            initMe(9, 11, Color.WHITE);
            setLabelsText("路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路", 0, 15, ROAD);
            setLabelsText("路路路路路路路路铺门铺路路路路路路站门站路路路路路所门所路路路", 0, 10, ROAD);
            setLabelsText("铺门铺", 8, 10, HOUSE);
            setLabelsText("门", 9, 10, DOOR0);
            setLabelsText("站门站", 17, 10, HOUSE);
            setLabelsText("门", 18, 10, 1, DOOR, Color.GRAY);
            setLabelsText("所门所", 25, 10, HOUSE);
            setLabelsText("门", 26, 10, DOOR0);
            setLabelsText("铺铺铺铺铺     站站站    所所所所所", 7, 9, HOUSE);
            setLabelsText("铺铺铺匠铺铺铺   站站修站站  所所所会所所所", 6, 8, HOUSE);
            setLabelsText("铺铺铁铺铺     站维站    所所集所所", 7, 7, HOUSE);
            setLabelsText("铺铺铺       站      所所所", 8, 6, HOUSE);
            setLabelsText("铺                所", 9, 5, HOUSE);
            setLabelsText("铁匠铺", 9, 7, 1, HOUSE, Color.BLUE);
            setLabelsText("维修站", 18, 7, 1, HOUSE, Color.BLUE);
            setLabelsText("集会所", 26, 7, 1, HOUSE, Color.BLUE);
        } else if (scene == 2) {
            clearLabels();
            setLabelsText("走进门我就看见魔导师伊塔力克正潜心研究，对我的到来毫无反应▼", 2, 4, 27, TEXT);
        } else if (scene == 3) {
            setLabelsText("我正想张口询问，伊塔力克缓缓地直起了身，仔细地打量我▼", 2, 7, 27, TEXT);
        } else if (scene == 4) {
            clearLabels();
            setLabelsText("「不必多言，」伊塔力克转身看向窗外，说：「你要是真有本事，就带着杜尔手套快快出发吧。」▼", 2, 4, 27, TEXT);
            setLabelsText("杜尔手套", 7, 5, 4, TEXT, Color.YELLOW);
        } else if (scene == 5) {
            setLabelsText("「但若你没本事的话，」伊塔力克话锋一转，面色冷峻「哼，无用之人不配成为勇者。」▼", 2, 7, 27, TEXT);
        } else if (scene == 6) {
            clearLabels();
            setLabelsText("我勉强控制住颤抖的双腿，神情肃然，深吸一口气道：「没问题，伊塔力克大师，我准备好了，我会用我的生命承担起勇者的重量！」▼", 2, 4, 27, TEXT);
        } else if (scene == 7) {
            setLabelsText("「这才像话嘛，」伊塔力克的表情放松下来，对我露出一个浅浅的微笑，说：「那么，我们现在就开始吧。」▼", 2, 8, 27, TEXT);
        } else if (scene == 8) {
            clearLabels();
            setLabelsText("魔导师伊塔力克在虚空中刻画出绚丽的法阵，光芒闪耀间，四面景象陡变，转眼已不在房间中，而不知到了何处···▼", 2, 6, 27, TEXT);
        } else if (scene == 9) {
            clearLabels();
            setLabelsText("「勇者，」虚无中传来伊塔力克的声音，「睁开眼睛，说说你看到了什么？」▼", 2, 4, 27, TEXT);
        } else if (scene == 10) {
            setLabelsText("「我······我什么也没看到」我实话实说。▼", 2, 7, 27, TEXT);
        } else if (scene == 11) {
            clearLabels();
            setLabelsText("「很好，」他说：「那现在呢，感受到手套的存在了吗？」▼", 2, 4, 27, TEXT);
        } else if (scene == 12) {
            setLabelsText("「我，我感受到了，我的手上有一股独特的力量，这，这就是杜尔手套吗。」我惊喜地握紧了手掌，杜尔手套的用法在心中油然而生。(按下L键激活杜尔手套后就可以拉动特定的文字了)▼", 2, 7,
                    27, TEXT);
        } else if (scene == 13) {
            clearLabels();
            setLabelsText("「别太得意了，勇者。你还没展现你的本事呢。仔细思考，勇闯未来的试炼吧」▼", 2, 4, 27, TEXT);
        } else if (scene == 14) {
            setLabelsText("伊塔力克的声音越来越小，仿佛是最后的叮嘱。突然间，空气中弥漫出别样的香气，我感觉昏昏欲睡······▼", 2, 7, 27, TEXT);
        } else if (scene == 15) {
            setLabelsText("待我清醒之时，我已身处牢狱之中，贝克思贝斯之剑也不知去向。幸好杜尔手套还在，也许还有办法出去···▼", 2, 10, 27, TEXT);
        } else {
            clearLabels();
            setLabelsText("墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙墙", 0, 15, MAX_COLUMN, WALL);
            setLabelsText("牢牢牢  牢牢牢牢牢牢牢牢牢  牢牢牢牢牢牢牢牢牢  牢牢牢牢", 0, 12, MAX_COLUMN, CAGE);
            setLabelsText("牢牢牢锁门牢牢牢牢牢牢牢牢牢锁门牢牢牢牢牢牢牢牢牢锁门牢牢牢牢", 0, 11, MAX_COLUMN, CAGE);
            setLabelsText("锁门", 3, 11, 2, DOOR1);
            setLabelsText("锁门", 14, 11, 2, DOOR1);
            setLabelsText("锁门", 25, 11, 2, DOOR1);
            setLabelsText("囚", 1, 9, 1, PEOPLE);
            setLabelsText("囚", 12, 9, 1, PEOPLE);
            setLabelsText("破床床", 6, 6, 1, BED);
            setLabelsText("破床床", 18, 6, 1, BED);
            setLabelsText("破床床", 27, 6, 1, BED);
            setLabelsText("破", 6, 6, 1, BOX);
            setLabelsText("破", 18, 6, 1, BOX);
            setLabelsText("破", 27, 6, 1, BOX);
            setLabelsText("墙墙墙墙墙墙", 9, 5, 1, WALL);
            setLabelsText("墙墙墙墙墙墙", 21, 5, 1, WALL);
            setLabelsText("牢牢牢牢牢牢", 30, 5, 1, CAGE);
            setLabelsText("牢牢窗户 牢牢牢牢牢牢牢牢窗户牢牢牢牢牢牢牢牢牢窗户牢牢牢牢牢", 0, 4, MAX_COLUMN, CAGE);
            setLabelsText("牢牢窗户牢牢牢牢牢牢牢牢牢窗户牢牢牢牢牢牢牢牢牢窗户牢牢牢牢牢", 0, 3, MAX_COLUMN, CAGE);
            setLabelsText("牢", 4, 3, 1, WALL);
            setLabelsText("窗户窗户", 2, 3, 2, WINDOW);
            setLabelsText("窗户窗户", 13, 3, 2, WINDOW);
            setLabelsText("窗户窗户", 24, 3, 2, WINDOW);
            setLabelsText("灯", 0, 3, 1, LIGHT, Color.ORANGE);
            setLabelsText("灯", 9, 3, 1, LIGHT, Color.ORANGE);
            setLabelsText("灯", 21, 3, 1, LIGHT, Color.ORANGE);
            setLabelsText("灯", 30, 3, 1, LIGHT, Color.ORANGE);
            setLabelsText("灯", 0, 12, 1, LIGHT, Color.ORANGE);
            setLabelsText("灯", 9, 12, 1, LIGHT, Color.ORANGE);
            setLabelsText("灯", 21, 12, 1, LIGHT, Color.ORANGE);
            setLabelsText("灯", 30, 12, 1, LIGHT, Color.ORANGE);
            setLabelsText("剑", 0, 14, 1, SWORD, Color.YELLOW);
            initMe(24, 9, Color.WHITE);
        }
    }

    /**
     * 朝指定方向移动“我”的位置,支持自定义类型的推拉判断(如还需推拉MOVE_TEXT类型,请手动添加) 更新了，推动箱子撞墙后可破墙
     *
     * @param direction UP:1, DOWN:2, LEFT:3, RIGHT:4
     * @param moveFlags 存有可以当做推拉块对待的文字标识符的数组
     */
    @Override
    void moveMe(int direction, int[] moveFlags) {
        if (meFLag) {
            // 暂存当前"我"的坐标及颜色
            int column = me_column, row = me_row;
            Color me_color = labels[me_row][me_column].getForeground();
            // 更新面朝的方向
            current_direction = direction;

            if (getFlag() == BLANK) {
                // 如果前面是空白,则可移动(可能是直接前进或拉)
                if (linkedFlag) {
                    // 处于连接模式,背后有可以拉的滑块,则带着滑块一起移动
                    if (hasFlagsBehind(moveFlags)) {
                        // 计算拉动块的原位置
                        int old_row = row, old_column = column;
                        if (direction == UP) {
                            row -= 1;
                            old_row += 1;
                        } else if (current_direction == DOWN) {
                            row += 1;
                            old_row -= 1;
                        } else if (current_direction == LEFT) {
                            column -= 1;
                            old_column += 1;
                        } else if (current_direction == RIGHT) {
                            column += 1;
                            old_column -= 1;
                        }
                        // 记录拉动块的文字、颜色及flag
                        String move_text = labels[old_row][old_column].getText();
                        Color move_color = labels[old_row][old_column].getForeground();
                        int move_flag = flags[old_row][old_column];
                        // 清除掉旧的拉动块
                        labels[old_row][old_column].setForeground(Color.WHITE);
                        labels[old_row][old_column].setText(" ");
                        flags[old_row][old_column] = BLANK;
                        // 在新位置上绘制拉动块(直接覆盖掉“我”)
                        labels[me_row][me_column].setForeground(move_color);
                        labels[me_row][me_column].setText(move_text);
                        flags[me_row][me_column] = move_flag;
                        // 在新位置上绘制拉动块(直接覆盖掉“我”)
                        labels[row][column].setForeground(me_color);
                        labels[row][column].setText("我");
                        flags[row][column] = BLANK;
                        // 更新坐标信息
                        me_column = column;
                        me_row = row;
                        return;
                    } else {
                        // 如果没有,直接断开连接
                        linkedFlag = false;
                    }
                } // 不用else,因为断开连接后“我”仍需要移动

                // 如果不处于连接模式,计算新的位置并移动
                if (direction == UP) {
                    row -= 1;
                } else if (current_direction == DOWN) {
                    row += 1;
                } else if (current_direction == LEFT) {
                    column -= 1;
                } else if (current_direction == RIGHT) {
                    column += 1;
                }
                // 清除旧位置上的“我”
                labels[me_row][me_column].setForeground(Color.WHITE);
                labels[me_row][me_column].setText(" ");
                // 在新位置上重新绘制“我”
                labels[row][column].setForeground(me_color);
                labels[row][column].setText("我");
                // 更新坐标信息
                me_column = column;
                me_row = row;

            } else if (hasFlagsFront(moveFlags) && !linkedFlag) { // 处于连接模式时不可以推
                // 看看滑块前是否有空间,有的话才能移动
                if (getFurtherFlag() == BLANK) {
                    int moveText_row = row, moveText_column = column;
                    if (direction == UP) {
                        row -= 1;
                        moveText_row -= 2;
                    } else if (current_direction == DOWN) {
                        row += 1;
                        moveText_row += 2;
                    } else if (current_direction == LEFT) {
                        column -= 1;
                        moveText_column -= 2;
                    } else if (current_direction == RIGHT) {
                        column += 1;
                        moveText_column += 2;
                    }
                    // 记录推动块的文字、颜色及flag
                    String move_text = labels[row][column].getText();
                    Color move_color = labels[row][column].getForeground();
                    int move_flag = flags[row][column];
                    // 清除旧位置上的“我”
                    labels[me_row][me_column].setForeground(Color.WHITE);
                    labels[me_row][me_column].setText(" ");
                    // 在新位置上重新绘制“我”(直接覆盖掉推动块)
                    labels[row][column].setForeground(me_color);
                    labels[row][column].setText("我");
                    flags[row][column] = BLANK;
                    // 在新位置上重新绘制推动块
                    labels[moveText_row][moveText_column].setForeground(move_color);
                    labels[moveText_row][moveText_column].setText(move_text);
                    flags[moveText_row][moveText_column] = move_flag;
                    // 更新坐标信息
                    me_column = column;
                    me_row = row;
                } else if (getFurtherFlag() == WALL) {
                    deleteFront();
                    deleteFurtherFront();
                }
            }
        }
    }

    /**
     * 删除当前面朝方向前面的文字
     */
    void deleteFurtherFront() {
        int column = me_column, row = me_row;
        // 计算待删字的位置,越界则直接返回
        if (current_direction == UP) {
            if (row > 1) {
                row -= 2;
            } else
                return;
        } else if (current_direction == DOWN) {
            if (row < MAX_ROW - 2) {
                row += 2;
            } else
                return;
        } else if (current_direction == LEFT) {
            if (column > 1) {
                column -= 2;
            } else
                return;
        } else if (current_direction == RIGHT) {
            if (column < MAX_COLUMN - 2) {
                column += 2;
            } else
                return;
        }
        labels[row][column].setForeground(Color.WHITE);
        labels[row][column].setText(" ");
        flags[row][column] = 0;
    }

    /**
     * 重置本关（时间回溯） 必要时进行覆写
     */
    @Override
    public void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        this.scene = 0;
        sword = false;
        initMap();
        this.setVisible(true);
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {
        Level5 level5;

        public MoveListener(Level5 panel) {
            this.level5 = panel;
        }

        public void keyTyped(KeyEvent e) {

        }

        /**
         * 获取指定长度的字符串,不够用空格补全,超过部分舍弃
         *
         * @param str        原字符串
         * @param separation 指定的长度
         * @return 指定长度的字符串
         */
        private String formatText(String str, int separation) {
            if (str.length() < separation) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                for (int i = str.length() - 1; i < separation; i++) {
                    stringBuilder.append(" ");
                }
                return stringBuilder.toString();
            } else if (str.length() == separation) {
                return str;
            } else {
                return str.substring(0, separation - 1);
            }
        }

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                int row = level5.me_row;
                int column = level5.me_column;
                if (flags[row + 1][column] == BOX && flags[row + 2][column] == DOOR1) {
                    setLabelsText(formatText("这样似乎行不通，撞门的声音会把狱卒吸引过来的！", 30), 3, 0, TEXT);
                } else {
                    level5.moveMe(DOWN, moveFlags);
                }
            } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                level5.moveMe(UP, moveFlags);
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                level5.moveMe(LEFT, moveFlags);
                if (level5.scene > 15) {
                    if (level5.me_column == 0 && level5.me_row == 13 || level5.me_column == 0 && level5.me_row == 14) {
                        setLabelsText(formatText("继续过去回碰见狱卒的，还是走另一边吧", 30), 3, 0, TEXT);
                    }
                } else if (level5.scene < 2) {
                    if (level5.me_column == 0) {
                        setLabelsText(formatText("开弓没有回头箭！！！", 25), 1, 1, TEXT);
                    }
                }
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                level5.moveMe(RIGHT, moveFlags);
                if (level5.scene > 15) {
                    if (level5.me_column == 30 && level5.me_row == 13
                            || level5.me_column == 30 && level5.me_row == 14) {
                        if (sword) {
                            level5.appFrame.removeListeners();
                            level5.appFrame.setWindow(new Level6(this.level5.appFrame));
                        } else {
                            setLabelsText(formatText("我好像忘了什么···", 30), 3, 0, TEXT);
                        }
                    }
                } else if (level5.scene < 2) {
                    if (level5.me_column == 30) {
                        setLabelsText(formatText("我要取得两件圣器才能打败恶龙", 25), 1, 1, TEXT);
                    }
                }

            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (level5.scene > 1 && level5.scene <= 15) {
                    level5.scene += 1;
                    initMap();
                }
                int flag = getFlag();
                if (flag == ROAD) {
                    setLabelsText(formatText("快向着目的地前进吧", 25), 1, 1, TEXT);
                } else if (flag == HOUSE) {
                    setLabelsText(formatText("这间房屋内有不同寻常的力量。。。", 25), 1, 1, TEXT);
                } else if (flag == DOOR0) {
                    setLabelsText(formatText("这里应该不是我要去的地方···", 25), 1, 1, TEXT);
                } else if (flag == DOOR) {
                    level5.clearLabels();
                    level5.scene = 2;
                    initMap();
                } else if (flag == DOOR1) {
                    setLabelsText(formatText("一扇铁门，理所当然的上了锁。若没有钥匙的话是不可能打开的", 30), 3, 0, TEXT);
                } else if (flag == WALL) {
                    setLabelsText(formatText("一面普通的墙，有着些许裂缝", 30), 3, 0, TEXT);
                } else if (flag == CAGE) {
                    setLabelsText(formatText("再怎么固若金汤的牢房，都会有漏洞", 30), 3, 0, TEXT);
                } else if (flag == BED) {
                    setLabelsText(formatText("休息是为了走更长的路···大概吧", 30), 3, 0, TEXT);
                } else if (flag == BOX) {
                    setLabelsText(formatText("留着破床，究竟有什么用？", 30), 3, 0, TEXT);
                } else if (flag == PEOPLE) {
                    setLabelsText(formatText("「没有钥匙，找到门你也别想出去」", 30), 3, 0, TEXT);
                    setLabelsText(formatText("钥匙", 2), 6, 0, 2, KEY, Color.GRAY);
                } else if (flag == WINDOW) {
                    setLabelsText(formatText("一扇牢固的窗户···", 30), 3, 0, TEXT);
                } else if (flag == LIGHT) {
                    setLabelsText(formatText("发出微弱光芒的油灯···", 30), 3, 0, TEXT);
                } else if (flag == KEY) {
                    setLabelsText(formatText("我的口袋里好像多了什么···", 30), 3, 0, TEXT);
                    setLabelsText("锁门", 25, 11, OPEN);
                    setLabelsText("锁门", 14, 11, OPEN);
                    setLabelsText("锁门", 3, 11, OPEN);
                } else if (flag == OPEN) {
                    setLabelsText(formatText("我用口袋中的钥匙打开了门！", 30), 3, 0, TEXT);
                    int column = level5.me_column;
                    if (column == 4) {
                        column = 3;
                    } else if (column == 15) {
                        column = 14;
                    } else if (column == 26) {
                        column = 25;
                    }
                    setLabelsText("  ", column, 11, BLANK);
                } else if (flag == SWORD) {
                    setLabelsText(" ", 0, 14, BLANK);
                    sword = true;
                    setLabelsText(formatText("我终于拿回了圣剑！", 30), 3, 0, TEXT);
                }
            } else if (e.getKeyCode() == KeyEvent.VK_L) {
                linkedFlag = !linkedFlag;
            } else if (e.getKeyCode() == KeyEvent.VK_K) {
                int flag = getFlag();
                if (sword) {
                    if (flag != BLANK) {
                        setLabelsText(formatText("圣剑不应该用来斩断这些无聊的东西···", 30), 3, 0, TEXT);
                    } else if (flag == BLANK) {
                        setLabelsText(formatText("我挥剑劈砍，但前面什么都没有···", 30), 3, 0, TEXT);
                    }
                } else {
                    setLabelsText(formatText("没有贝克思贝斯之剑我是无法打败恶龙的", 30), 3, 0, TEXT);
                }
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
