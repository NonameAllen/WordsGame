import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 第三关的界面,实现地图及交互
 *
 * @author 2020303118_CLY
 * @version 1.0.1
 */
public class Level6 extends Level {

    // 拓展的交互类型
    static final int ROAD = 3;
    static final int HOUSE = 4;
    static final int DOOR = 5;
    static final int DOOR0 = 6;
    static final int NORTH = 7;
    static final int SOUTH = 8;
    static final int EAST = 9;
    static final int WEST = 10;

    boolean north = false;
    boolean south = false;
    boolean east = false;
    boolean west = false;

    int scene;

    public Level6(AppFrame frame) {
        super(frame);
        scene = 1;
        this.appFrame.addKeyListener(new MoveListener(this));
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (scene == 0) {
            initMe(18, 11, Color.WHITE);
            setLabelsText("路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路路", 0, 15, ROAD);
            setLabelsText("路路路路路路路路铺门铺路路路路路路站门站路路路路路所门所路路路", 0, 10, ROAD);
            setLabelsText("铺门铺", 8, 10, HOUSE);
            setLabelsText("门", 9, 10, DOOR0);
            setLabelsText("站门站", 17, 10, HOUSE);
            setLabelsText("门", 18, 10, DOOR0);
            setLabelsText("所门所", 25, 10, HOUSE);
            setLabelsText("门", 26, 10, DOOR0);
            setLabelsText("铺铺铺铺铺     站站站    所所所所所", 7, 9, HOUSE);
            setLabelsText("铺铺铺匠铺铺铺   站站修站站  所所所会所所所", 6, 8, HOUSE);
            setLabelsText("铺铺铁铺铺     站维站    所所集所所", 7, 7, HOUSE);
            setLabelsText("铺铺铺       站      所所所", 8, 6, HOUSE);
            setLabelsText("铺                所", 9, 5, HOUSE);
            setLabelsText("铁匠铺", 9, 7, 1, HOUSE, Color.BLUE);
            setLabelsText("维修站", 18, 7, 1, HOUSE, Color.BLUE);
            setLabelsText("集会所", 26, 7, 1, HOUSE, Color.BLUE);

        } else if (scene == 2) {
            clearLabels();
            setLabelsText("我背上贝克思贝斯之剑，戴好杜尔手套，坚定地踏上了讨伐恶龙、拯救世人的征途。▼                      ", 4, 1, 20, TEXT);
        } else if (scene == 3) {
            setLabelsText("不过，哪条路才是去往龙堡的呢？▼                                            ", 4, 6, 20, TEXT);
        } else if (scene == 4) {
            setLabelsText("「······」▼                                                   ", 4, 11, 20, TEXT);
        } else if (scene == 5) {
            clearLabels();
            setLabelsText("看着我犹豫不前的样子，似乎连藏身于森林深处的恶魔也看不下去了▼                             ", 4, 1, 20, TEXT);
        } else if (scene == 6) {
            setLabelsText("恶魔嘶吼着向我袭来，我在惊慌中被打了个措手不及▼                                    ", 4, 6, 20, TEXT);
        } else if (scene == 7) {
            setLabelsText("「不会吧，我竟然连这种危险也无法解决吗···」我心中有了一丝绝望▼                           ", 4, 11, 20, TEXT);
        } else if (scene == 8) {
            clearLabels();
            setLabelsText("「呼··呼···呼······呼···」▼                                       ", 4, 1, 20, TEXT);
        } else if (scene == 9) {
            setLabelsText("我以一身伤的代价，拼死干掉了恶魔▼                                           ", 4, 6, 20, TEXT);
        } else if (scene == 10) {
            clearLabels();
            setLabelsText("「未来的道路也会如此凶险吗···」我心中踌躇道▼                                    ", 4, 6, 20, TEXT);
        } else if (scene == 11) {
            setLabelsText("「即使这样，，，即使这样，我也要继续向前，只有打倒更多敌人，我才能变得更强，才能走到恶龙面前，亲手打败它！」▼     ", 4, 11, 20, TEXT);
        } else if (scene == 12) {
            clearLabels();
            setLabelsText("我现在应该前往", 11, 8, 7, TEXT);
            setLabelsText("北之冰川荒原", 10, 1, 6, TEXT);
            setLabelsText("南之神秘森林", 10, 13, 6, TEXT);
            setLabelsText("西之地狱沙漠", 4, 4, 1, TEXT);
            setLabelsText("东之迷雾沼泽", 23, 4, 1, TEXT);
            setLabelsText("北", 10, 1, 1, NORTH, Color.BLUE);
            setLabelsText("南", 10, 13, 1, SOUTH, Color.GRAY);
            setLabelsText("西", 4, 4, 1, WEST, Color.ORANGE);
            setLabelsText("东", 23, 4, 1, EAST, Color.GREEN);
            initMe(11, 8, Color.WHITE);
        } else if (scene == 13) {
            clearLabels();
            setLabelsText("来到北方的冰川荒原，我忍受刺骨的寒风和躲避野狼的追寻，终于找到了北方君王「独眼暴君」的领地▼", 4, 3, 20, TEXT);
        } else if (scene == 14) {
            setLabelsText("大战了三天三夜，即使寒冰也难以冻结我的因受伤而挥洒的热血，虽然过程艰辛但结果值得，我自豪的带回了战利品「独眼暴君之眼」▼", 4, 9, 20, TEXT);
            setLabelsText("独眼暴君之眼", 16, 11, 6, TEXT, Color.BLUE);
        } else if (scene == 15) {
            clearLabels();
            setLabelsText("来到南方的神秘森林，阴阴冷风吹来一丝丝诡异，我无畏地向前，仔细勘察着南方君王「幽冥影豹」的痕迹▼", 4, 3, 20, TEXT);
        } else if (scene == 16) {
            setLabelsText("我自知比不过它的速度，于是善用计谋并用我的鲜血勾引，最终将其坑杀于我精心设计的陷阱中，得到了「幽冥影豹之牙」▼", 4, 9, 20, TEXT);
            setLabelsText("幽冥影豹之牙", 11, 11, 6, TEXT, Color.GRAY);
        } else if (scene == 17) {
            clearLabels();
            setLabelsText("跋涉在西方一望无际的沙漠中，身受堪比地狱业火的炙烤，正当我寻得一处绿洲可以乘凉，却见西方君王「美杜莎女王」已在其中，大战一触即发▼", 4, 3, 20, TEXT);
        } else if (scene == 18) {
            setLabelsText("所幸我时刻注意躲避美杜莎的眼光，跳跃腾挪间斩剑于其七寸，取得了「美杜莎之首」▼", 4, 9, 20, TEXT);
            setLabelsText("美杜莎之首", 16, 10, 5, TEXT, Color.ORANGE);
        } else if (scene == 19) {
            clearLabels();
            setLabelsText("来到东方的迷雾沼泽，我轻装简行，绕过噬人的蚁军和咕噜冒泡的沼泽，跟随偶见的异色花寻到了东方君王「荆棘魔花」▼", 4, 3, 20, TEXT);
        } else if (scene == 20) {
            setLabelsText("我利用植物惧火的特性，举着火把与其周旋，终于在身体达到极限之前将其斩杀，我顾不得流血的伤口上前割下了「荆棘魔花之叶」▼", 4, 9, 20, TEXT);
            setLabelsText("荆棘魔花之叶", 15, 11, 6, TEXT, Color.GREEN);
        } else if (scene == 21) {
            clearLabels();
            setLabelsText("我继续向前走，                        ", 0, 4, TEXT);
            setLabelsText("一路披荆斩棘。                        ", 0, 11, TEXT);
            initMe(0, 7, Color.WHITE);
        } else if (scene == 22) {
            setLabelsText("不能干掉我的，                 ", 7, 4, TEXT);
            setLabelsText("终将使我更强。                 ", 7, 11, TEXT);
        } else if (scene == 23) {
            setLabelsText("一声声屠龙的期望，       ", 14, 4, TEXT);
            setLabelsText("逐渐引导我的内心。      ", 14, 11, TEXT);
        } else if (scene == 24) {
            setLabelsText("杀的恶魔越来越多", 23, 4, TEXT);
            setLabelsText("心中的火越来越旺", 23, 11, TEXT);
        } else if (scene == 25) {
            clearLabels();
            setLabelsText("黑暗中不断冒出的敌人仿佛就是最好的指路牌▼    ", 4, 6, 25, TEXT);
        } else if (scene == 26) {
            setLabelsText("将我引向那最终的目的地，龙堡▼          ", 4, 8, 25, TEXT);
            setLabelsText("龙堡", 16, 8, 2, TEXT, Color.RED);
        } else if (scene == 27) {
            clearLabels();
            setLabelsText("「终于要结束了吗，那就从正门杀进去吧！」我拿好圣器，推门而入      ", 4, 6, 20, TEXT);
            setLabelsText("门", 17, 6, 1, DOOR, Color.GRAY);
            initMe(4, 7, Color.WHITE);
        }
    }

    /**
     * 重置本关（时间回溯） 必要时进行覆写
     */
    @Override
    public void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        this.scene = 0;
        north = false;
        south = false;
        west = false;
        east = false;
        initMap();
        this.setVisible(true);
    }

    /**
     * 判断“我”移动情况的键盘监听器
     */
    private class MoveListener implements KeyListener {
        Level6 level6;

        public MoveListener(Level6 panel) {
            this.level6 = panel;
        }

        public void keyTyped(KeyEvent e) {

        }

        /**
         * 获取指定长度的字符串,不够用空格补全,超过部分舍弃
         *
         * @param str        原字符串
         * @param separation 指定的长度
         * @return 指定长度的字符串
         */
        private String formatText(String str, int separation) {
            if (str.length() < separation) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                for (int i = str.length() - 1; i < separation; i++) {
                    stringBuilder.append(" ");
                }
                return stringBuilder.toString();
            } else if (str.length() == separation) {
                return str;
            } else {
                return str.substring(0, separation - 1);
            }
        }

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                level6.moveMe(DOWN);
            } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                level6.moveMe(UP);
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                level6.moveMe(LEFT);
                if (level6.scene < 2) {
                    if (level6.me_column == 0) {
                        setLabelsText(formatText("前进的方向好像错了", 25), 1, 1, TEXT);
                    }
                }
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                level6.moveMe(RIGHT);
                if (level6.scene < 2) {
                    if (level6.me_column == 30) {
                        clearLabels();
                        level6.scene = 2;
                        initMap();
                    }
                } else if (level6.scene >= 21 && level6.scene <= 24) {
                    if (level6.me_column == 6) {
                        level6.scene += 1;
                        initMap();
                    } else if (level6.me_column == 13) {
                        level6.scene += 1;
                        initMap();
                    } else if (level6.me_column == 22) {
                        level6.scene += 1;
                        initMap();
                    } else if (level6.me_column == 30) {
                        clearLabels();
                        level6.scene = 25;
                        initMap();
                    }
                }
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (level6.scene > 1 && level6.scene <= 11 || level6.scene >= 25 && level6.scene <= 26) {
                    level6.scene += 1;
                    initMap();
                } else if (level6.scene == 13 || level6.scene == 15 || level6.scene == 17 || level6.scene == 19) {
                    level6.scene += 1;
                    initMap();
                } else if (level6.scene == 14 || level6.scene == 16 || level6.scene == 18 || level6.scene == 20) {
                    if (north && south && west && east) {
                        clearLabels();
                        level6.scene = 21;
                        initMap();
                    } else {
                        clearLabels();
                        level6.scene = 12;
                        initMap();
                    }
                } else {
                    int flag = getFlag();
                    if (flag == ROAD) {
                        setLabelsText(formatText("沿着这条路去往龙堡吧", 25), 1, 1, TEXT);
                    } else if (flag == HOUSE) {
                        setLabelsText(formatText("他们还期待着我屠龙凯旋呢", 25), 1, 1, TEXT);
                    } else if (flag == DOOR0) {
                        setLabelsText(formatText("现在就不打扰他们了吧", 25), 1, 1, TEXT);
                    } else if (flag == DOOR) {
                        level6.appFrame.removeListeners();
                        level6.appFrame.setWindow(new Final(this.level6.appFrame));
                    } else if (flag == NORTH && !north) {
                        clearLabels();
                        level6.scene = 13;
                        north = true;
                        initMap();
                    } else if (flag == SOUTH && !south) {
                        clearLabels();
                        level6.scene = 15;
                        south = true;
                        initMap();
                    } else if (flag == WEST && !west) {
                        clearLabels();
                        level6.scene = 17;
                        west = true;
                        initMap();
                    } else if (flag == EAST && !east) {
                        clearLabels();
                        level6.scene = 19;
                        east = true;
                        initMap();
                    }
                }
            } else if (e.getKeyCode() == KeyEvent.VK_L) {
                linkedFlag = !linkedFlag;
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
