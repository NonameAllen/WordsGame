import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * 日志类
 *
 * @author 2020303122_LJX
 * @version 1.0.0
 */
public class LoggerUtil {

    public static final Level OFF = Level.OFF;
    public static final Level SEVERE = Level.SEVERE;
    public static final Level WARNING = Level.WARNING;
    public static final Level INFO = Level.INFO;
    public static final Level CONFIG = Level.CONFIG;
    public static final Level FINE = Level.FINE;
    public static final Level FINER = Level.FINER;
    public static final Level FINEST = Level.FINEST;
    public static final Level ALL = Level.ALL;
    // 存放的文件夹
    private static final String path_name = "WordsGame_Log";
    // 单例模式提供一个logger
    private static Logger logger;

    /**
     * 得到要记录的日志的路径及文件名称
     */
    private static String getLogName() {
        StringBuilder logPath = new StringBuilder();
        logPath.append(System.getProperty("user.dir"));
        logPath.append("\\" + path_name);
        File file = new File(logPath.toString());
        if (!file.exists()) {
            file.mkdir();
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        logPath.append("\\").append(sdf.format(new Date())).append(".log");

        return logPath.toString();
    }

    /**
     * 配置Logger对象输出日志文件路径
     */
    public static void setLoggingProperties(Logger logger) {
        setLoggingProperties(logger, Level.ALL);
    }

    /**
     * 配置Logger对象输出日志文件路径
     */
    public static void setLoggingProperties(Logger logger, Level level) {
        FileHandler fh;
        try {
            fh = new FileHandler(getLogName(), true);
            logger.addHandler(fh);//日志输出文件
            logger.setLevel(level);
            fh.setFormatter(new SimpleFormatter());//输出格式
            //logger.addHandler(new ConsoleHandler());//输出到控制台
        } catch (SecurityException e) {
            logger.log(Level.SEVERE, "安全性错误", e);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "读取文件日志错误", e);
        }
    }

    /**
     * 提供一个单例模式的logger
     */
    public static Logger getLogger() {
        if (logger == null) {
            logger = Logger.getLogger("WordsGameLog");
            LoggerUtil.setLoggingProperties(logger);
        }
        return logger;
    }

    /*测试用
    public static void main(String[] args) {
        Logger logger = getLogger();
        logger.log(Level.INFO, "测试信息1");
        logger.log(Level.INFO, "测试信息2");
        logger.log(Level.INFO, "测试信息3");
        logger.log(Level.INFO, "测试信息4");
        logger.log(Level.INFO, "测试信息5");
    }
     */
}