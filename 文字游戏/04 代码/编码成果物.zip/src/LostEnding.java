import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * 迷路结局
 *
 * @author 2020303122_LJX
 * @version 1.0.0
 */
public class LostEnding extends Level {

    int step = 0;

    public LostEnding(AppFrame frame) {
        super(frame);
        this.appFrame.addKeyListener(new MyKeyListener(this));
        this.setVisible(true);
    }

    @Override
    void reset() {
        this.clearLabels();
        me_row = 0;
        me_column = 0;
        current_direction = 0;
        meFLag = false;
        linkedFlag = false;
        step = 0;
        initMap();
        this.setVisible(true);
    }

    /**
     * 初始化地图
     */
    void initMap() {
        if (step == 0) {
            setLabelsText("我", 2, 2, 1, TEXT,
                    new Color(255, 163, 0), new Font("宋体", Font.BOLD, SIZE_OF_EACH_LABEL - 3));
            setLabelsText("一路西行", 2, 3, 1, TEXT, Color.WHITE);
            setLabelsText("却  进入了", 3, 5, 1, TEXT, Color.WHITE);
            setLabelsText("失足", 3, 6, 1, TEXT, new Color(235, 0, 255));
            setLabelsText("恶龙的城堡", 4, 8, 1, TEXT,
                    new Color(136, 55, 217), new Font("宋体", Font.BOLD, SIZE_OF_EACH_LABEL - 3));
            setLabelsText("▼", 4, 14, 1, TEXT, Color.BLUE);
        } else if (step == 1) {
            setLabelsText("在一片黑暗中", 8, 2, 1, TEXT, Color.WHITE);
            setLabelsText("我", 9, 5, 1, TEXT,
                    new Color(255, 163, 0), new Font("宋体", Font.BOLD, SIZE_OF_EACH_LABEL - 3));
            setLabelsText("只", 9, 6, 1, TEXT, Color.WHITE);
            setLabelsText("看到了恶龙", 9, 7, 1, TEXT, new Color(0, 225, 255));
            setLabelsText("血红的眼睛", 10, 8, 1, TEXT,
                    Color.RED, new Font("宋体", Font.BOLD, SIZE_OF_EACH_LABEL - 3));
            setLabelsText("▼", 10, 14, 1, TEXT, Color.BLUE);
        } else if (step == 2) {
            setLabelsText("恶龙的  挥下", 14, 2, 1, TEXT, Color.WHITE);
            setLabelsText("利爪", 14, 5, 1, TEXT,
                    new Color(103, 231, 34), new Font("宋体", Font.BOLD, SIZE_OF_EACH_LABEL - 3));
            setLabelsText("我", 15, 5, 1, TEXT,
                    new Color(255, 163, 0), new Font("宋体", Font.BOLD, SIZE_OF_EACH_LABEL - 3));
            setLabelsText("重重地飞了出去", 15, 6, 1, TEXT, Color.WHITE);
            setLabelsText("▼", 15, 14, 1, TEXT, Color.BLUE);
        } else if (step == 3) {
            setLabelsText("真的要在这里    ？", 19, 2, 1, TEXT, Color.WHITE);
            setLabelsText("结束了吗", 19, 8, 1, TEXT,
                    Color.RED, new Font("宋体", Font.BOLD, SIZE_OF_EACH_LABEL - 3));
            setLabelsText("▼", 19, 14, 1, TEXT, Color.BLUE);
        } else if (step == 4) {
            setLabelsText("来不及后悔", 23, 2, 1, TEXT, Color.WHITE);
            setLabelsText("我", 24, 5, 1, TEXT,
                    new Color(255, 163, 0), new Font("宋体", Font.BOLD, SIZE_OF_EACH_LABEL - 3));
            setLabelsText("两眼一黑", 24, 6, 1, TEXT, Color.WHITE);
            setLabelsText("失去了知觉", 25, 8, 1, TEXT, Color.WHITE);
            setLabelsText("▼", 25, 14, 1, TEXT, Color.BLUE);
        } else if (step == 5) {
            setLabelsText("达成结局", 28, 4, 1, TEXT, Color.RED);
            setLabelsText("路痴", 28, 10, 1, TEXT,
                    Color.RED, new Font("华文新魏", Font.PLAIN, SIZE_OF_EACH_LABEL));
        }
    }


    private class MyKeyListener implements KeyListener {

        LostEnding ending;

        public MyKeyListener(LostEnding endingPanel) {
            this.ending = endingPanel;
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                if (ending.step < 5) {
                    ending.step += 1;
                    initMap();
                } else {
                    ending.appFrame.removeListeners();
                    ending.appFrame.setWindow(new MainMenu(this.ending.appFrame));
                }
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
