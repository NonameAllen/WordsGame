import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * 程序的主界面
 *
 * @author 2020303122_LJX
 * @version 1.0.3
 */
public class MainMenu extends JPanel {
    //窗口宽高
    static final int WIDTH = AppFrame.WIDTH;
    static final int HEIGHT = AppFrame.HEIGHT;
    //保存三个出现“我”的地方的坐标信息及“我”的宽高
    static final int me_width = 65, me_height = 60;
    static final int me0_x = (WIDTH / 2) + 66, me0_y = (HEIGHT / 2) - 75;
    static final int me1_x = (WIDTH / 2) - 465, me1_y = (HEIGHT / 2) + 150;
    static final int me2_x = (WIDTH / 2) + 85, me2_y = (HEIGHT / 2) + 150;
    AppFrame appFrame;
    JLabel gameTitle, tipLabel, tip, newGame, exitGame, me;
    Color me_color, newGame_color, exitGame_color;
    //保存当前选择
    int option = 0;

    public MainMenu(AppFrame frame) {
        this.appFrame = frame;
        initMainMenu();
    }

    /**
     * 初始化界面内容
     */
    void initMainMenu() {
        //背景色为黑
        this.setBackground(Color.BLACK);
        //手工布局
        this.setLayout(null);

        gameTitle = new JLabel("文 字 游 戏");
        gameTitle.setFont(new Font("华文新魏", Font.BOLD, 200));
        gameTitle.setForeground(Color.WHITE);
        gameTitle.setBounds((WIDTH / 2) - 522, (HEIGHT / 2) - 340, 1025, 200);
        this.add(gameTitle);

        tipLabel = new JLabel("这是一段关于“  ”的故事");
        tipLabel.setFont(new Font("宋体", Font.PLAIN, 50));
        tipLabel.setForeground(Color.YELLOW);
        tipLabel.setBounds((WIDTH / 2) - 280, (HEIGHT / 2) - 70, 600, 50);
        this.add(tipLabel);

        //”我“是游戏的主角,同时也起到指示选项的功能
        me = new JLabel("我");
        me.setFont(new Font("宋体", Font.BOLD, 60));
        me_color = Color.YELLOW;
        me.setForeground(me_color);
        me.setBounds((WIDTH / 2) + 66, (HEIGHT / 2) - 75, 65, 60);
        this.add(me);

        //给玩家操作提示
        tip = new JLabel("使用方向键进行选择");
        tip.setFont(new Font("华文行楷", Font.PLAIN, 40));
        tip.setForeground(Color.ORANGE);
        tip.setBounds((WIDTH / 2) - 180, (HEIGHT / 2) + 35, 400, 60);
        this.add(tip);

        newGame = new JLabel("开始冒险");
        newGame_color = Color.WHITE;
        newGame.setForeground(newGame_color);
        newGame.setFont(new Font("宋体", Font.BOLD, 60));
        newGame.setBounds((WIDTH / 2) - 400, (HEIGHT / 2) + 150, 252, 60);
        //添加鼠标监听器
        newGame.addMouseListener(new NewGameListener(this));
        this.add(newGame);

        exitGame = new JLabel("离开游戏");
        exitGame_color = Color.WHITE;
        exitGame.setForeground(exitGame_color);
        exitGame.setFont(new Font("宋体", Font.BOLD, 60));
        exitGame.setBounds((WIDTH / 2) + 150, (HEIGHT / 2) + 150, 252, 60);
        //添加鼠标监听器
        exitGame.addMouseListener(new ExitGameListener(this));
        this.add(exitGame);

        //为窗口添加键盘监听器
        OptionListener optionListener = new OptionListener(this);
        appFrame.addKeyListener(optionListener);
    }

    /**
     * 重置
     */
    void reset() {
        me.setBounds(me0_x, me0_y, me_width, me_height);
        option = 0;
        me_color = Color.YELLOW;
        newGame_color = Color.WHITE;
        exitGame_color = Color.WHITE;
        me.setForeground(me_color);
        newGame.setForeground(newGame_color);
        exitGame.setForeground(exitGame_color);
        this.repaint();
    }

    /**
     * newGame标签的鼠标监听器
     */
    private static class NewGameListener implements MouseListener {
        MainMenu mainMenu;

        public NewGameListener(MainMenu panel) {
            this.mainMenu = panel;
        }

        public void mouseClicked(MouseEvent e) {
            if (e.getButton() == 1) {
                mainMenu.appFrame.removeListeners();
                mainMenu.appFrame.setWindow(new Level1(mainMenu.appFrame));
            }
        }

        public void mousePressed(MouseEvent e) {

        }

        public void mouseReleased(MouseEvent e) {

        }

        public void mouseEntered(MouseEvent e) {
            mainMenu.newGame.setForeground(Color.GREEN);
        }

        public void mouseExited(MouseEvent e) {
            if (!mainMenu.newGame_color.equals(Color.GREEN)) {
                mainMenu.newGame.setForeground(Color.WHITE);
            }
        }
    }

    /**
     * exitGame标签的鼠标监听器
     */
    private static class ExitGameListener implements MouseListener {
        MainMenu mainMenu;

        public ExitGameListener(MainMenu panel) {
            this.mainMenu = panel;
        }

        public void mouseClicked(MouseEvent e) {
            if (e.getButton() == 1) {
                mainMenu.appFrame.dispose();
                System.exit(0);
            }
        }

        public void mousePressed(MouseEvent e) {

        }

        public void mouseReleased(MouseEvent e) {

        }

        public void mouseEntered(MouseEvent e) {
            mainMenu.exitGame.setForeground(Color.RED);
        }

        public void mouseExited(MouseEvent e) {
            if (!mainMenu.exitGame_color.equals(Color.RED)) {
                mainMenu.exitGame.setForeground(Color.WHITE);
            }
        }
    }

    /**
     * 键盘监听器类,控制“我”的移动和交互
     */
    private class OptionListener implements KeyListener {
        MainMenu mainMenu;

        public OptionListener(MainMenu panel) {
            this.mainMenu = panel;
            option = 0;
        }

        public void keyTyped(KeyEvent e) {

        }

        public void keyPressed(KeyEvent e) {

            if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
                if (option == 0) {
                    mainMenu.me.setBounds(me1_x, me1_y, me_width, me_height);
                    option = 1;
                    me_color = Color.WHITE;
                    newGame_color = Color.GREEN;
                    me.setForeground(me_color);
                    newGame.setForeground(newGame_color);
                    mainMenu.repaint();
                }
            } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
                if (option != 0) {
                    mainMenu.me.setBounds(me0_x, me0_y, me_width, me_height);
                    option = 0;
                    me_color = Color.YELLOW;
                    newGame_color = Color.WHITE;
                    exitGame_color = Color.WHITE;
                    me.setForeground(me_color);
                    newGame.setForeground(newGame_color);
                    exitGame.setForeground(exitGame_color);
                    mainMenu.repaint();
                }
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
                if (option == 1) {
                    mainMenu.me.setBounds(me2_x, me2_y, me_width, me_height);
                    option = 2;
                    me_color = Color.WHITE;
                    newGame_color = Color.WHITE;
                    exitGame_color = Color.RED;
                    me.setForeground(me_color);
                    newGame.setForeground(newGame_color);
                    exitGame.setForeground(exitGame_color);
                    mainMenu.repaint();
                }
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
                if (option == 2) {
                    mainMenu.me.setBounds(me1_x, me1_y, me_width, me_height);
                    option = 1;
                    me_color = Color.WHITE;
                    newGame_color = Color.GREEN;
                    exitGame_color = Color.WHITE;
                    me.setForeground(me_color);
                    newGame.setForeground(newGame_color);
                    exitGame.setForeground(exitGame_color);
                    mainMenu.repaint();
                }
            } else if (e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyCode() == KeyEvent.VK_ENTER) {
                if (option == 1) {
                    option = 0;
                    mainMenu.appFrame.removeListeners();
                    mainMenu.appFrame.setWindow(new Level1(mainMenu.appFrame));
                } else if (option == 2) {
                    mainMenu.appFrame.dispose();
                    System.exit(0);
                }
            }
        }

        public void keyReleased(KeyEvent e) {

        }
    }
}
